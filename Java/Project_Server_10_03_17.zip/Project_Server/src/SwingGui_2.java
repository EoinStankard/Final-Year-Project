/**
 * Created by h on 29/11/2016.
 */

import net.miginfocom.swing.MigLayout;

import java.awt.event.KeyEvent;
import java.io.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.ServerSocket;
import java.net.Socket;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Highlighter;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;


public class SwingGui_2 extends JApplet{
    JTextArea Txt1,Txt2,Txt3,Txt4,Txt5;
    JTextArea P2_Txt1,display;
    JPasswordField pWord;
    JTextField rn, RLText,ErrorText,DSText,CText,RoomNoText;
    JButton DoorLock,Database,Clear,unLock,Lock,DataSearch,CleanerLock,RoomNo,UpdateChange,confirm;
    JLabel label,labelR,labelC,p2_label,EntertainmentName;
    String number431="431",number436="436",number593="593";
    ClientServiceThread[] CST;
    Connection conn;
    int clientCount=0;
    JTabbedPane tabbedPane = new javax.swing.JTabbedPane();
    String room1="436";
    String room2="593";
    String room3="431";
    int lineNumber=0;

    String room431Pword,room436Pword,room593Pword;
    String Pword431,Pword436,Pword593;
    String appRoom431,appRoom436,appRoom593;
    String EntName ="N/A";
    String AndroidEntertainment;
    String BoardRNum;
    int id,endIndexRest,startIndexRest,restCount=0;
    int room431ID,appID,room436ID,room593ID;
    Highlighter.HighlightPainter painter;

    public static void main(String[] args) {
        try{
           UIManager.setLookAndFeel("com.jtattoo.plaf.texture.TextureLookAndFeel");//"com.jtattoo.plaf.acryl.AcrylLookAndFeel"
        }
        catch(Exception ex ){
            ex.printStackTrace();
        }
        new SwingGui_2();
    }


    /*****************************************************************************************************
     *
     ****************************************************************************************************/
    public SwingGui_2() {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {

                GUI();
            }
        });
    }
    /*****************************************************************************************************
     *
     ****************************************************************************************************/
    private void GUI() {
        JFrame frame = new JFrame("Hotel Server");
        frame.setSize(1372,738);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ////////TABS//////////////////////
        JPanel tabPane=new JPanel(new BorderLayout());
        JPanel tabPane1=new JPanel(new BorderLayout());
        JPanel tabPane2 =new JPanel(new BorderLayout());
        JPanel tabPane3 = new JPanel (new MigLayout("center"));
        JPanel tabPane4 =new JPanel(new BorderLayout());
        /////////////Panels////////////////////////
        JPanel westPanel = new JPanel();
        JPanel eastPanel = new JPanel();
        JPanel northPanel = new JPanel();
        JPanel pane1Panel = new JPanel();
        //**********************************************  TAB HOME*****************************************************************

        pane1Panel.setLayout(new GridLayout(10,1));
        JLabel name =new JLabel("<html>Eoin Stankard<br></html>", SwingConstants.CENTER);
        name.setFont(new Font("Calibri", Font.BOLD, 30));
        JLabel course =new JLabel("<html>Computer and Electronic Engineering<br></html>", SwingConstants.CENTER);
        course.setFont(new Font("Calibri", Font.BOLD, 30));
        JLabel fyp =new JLabel("<html>Final Year Project<br></html>", SwingConstants.CENTER);
        fyp.setFont(new Font("Calibri", Font.BOLD, 30));
        JLabel roomN =new JLabel("<html>Room Number<br></html>", SwingConstants.CENTER);
        roomN.setFont(new Font("Calibri", Font.ITALIC, 24));
        JLabel password =new JLabel("<html>Password<br></html>", SwingConstants.CENTER);
        password.setFont(new Font("Calibri", Font.ITALIC, 24));

        confirm = new JButton("Confirm");
        confirm.setFont(new Font("Calibri", Font.PLAIN, 24));
        JPanel panel =new JPanel(new FlowLayout());
        panel.add(confirm);

        JPanel p = new JPanel(new GridLayout(1,4));
        rn = new JTextField();
        rn.setFont(new Font("Calibri", Font.PLAIN, 24));
        rn.setHorizontalAlignment(SwingConstants.CENTER);
        JLabel lll =new JLabel();
        JLabel ll =new JLabel();
        p.add(lll);p.add(rn);p.add(ll);

        JPanel r =new JPanel(new GridLayout(1,4));
        //pWord = new JTextField();
        //pWord.setFont(new Font("Calibri", Font.PLAIN, 24));
        //pWord.setHorizontalAlignment(SwingConstants.CENTER);
        pWord = new JPasswordField();
        pWord.setFont(new Font("Calibri", Font.PLAIN, 24));
        pWord.setHorizontalAlignment(SwingConstants.CENTER);
        pWord.setEchoChar('*');
        JLabel rr =new JLabel();
        JLabel rrr =new JLabel();
        r.add(rr);
        r.add(pWord);
        r.add(rrr);

        pane1Panel.add(name);
        pane1Panel.add(course);
        pane1Panel.add(fyp);
        pane1Panel.add(roomN);
        pane1Panel.add(p);
        pane1Panel.add(password);
        pane1Panel.add(r);
        pane1Panel.add(panel);
        tabPane.add(pane1Panel);


        frame.getContentPane().add(northPanel, "North");
        frame.getContentPane().add(westPanel, "West");
        frame.getContentPane().add(eastPanel, "Center");
        //eastPanel.setLayout(new FlowLayout());
        eastPanel.setLayout(new MigLayout("center"));
        eastPanel.setBackground(Color.decode("#90989E"));
        //westPanel.setLayout(new GridLayout(10,1));

        //**********************************************  TAB ROOM CONFIG*****************************************************************
        westPanel.setLayout(new MigLayout("debug"));

        JLabel Header =new JLabel("Automated Hotel\n");
        Clear = new JButton("Clear");
        Database = new JButton("Database");
        DoorLock = new JButton("Lock/Unlock Room");
        RoomNo = new JButton("Room No.");
        //JButton Search = new JButton("Search");

        westPanel.add(Clear,"center,width 80:150:150,wrap");
        westPanel.add(Database,"center,width 80:150:150,wrap");
        westPanel.add(DoorLock,"center,width 80:150:150,wrap");
        westPanel.add(RoomNo,"center,width 80:150:150,wrap");
        westPanel.setBackground(Color.decode("#90989E"));
        Header.setFont(new Font("Calibri", Font.BOLD, 32));
        northPanel.add(Header);
        northPanel.setBackground(Color.red);

        //upperPanel.add(Search);
        Txt1 = new JTextArea(38, 32);
        //Txt1.setBorder(BorderFactory.createLineBorder(Color.RED));
        Txt1.setEditable(false);
        Txt1.setLineWrap(true);
        Txt1.setWrapStyleWord(true);
        Txt1.setFont(new Font("Calibri", Font.PLAIN, 16));
        Txt1.append("Status:\t\tDate:              Time:\n\n");
        eastPanel.add(new JScrollPane(Txt1),"span, split 3, center");

        Txt5 = new JTextArea(38, 32);
        Txt5.setEditable(false);
        Txt5.setLineWrap(true);
        Txt5.setWrapStyleWord(true);
        Txt5.setFont(new Font("Calibri", Font.PLAIN, 16));
        Txt5.append("Room Config:\n\n");
        eastPanel.add(new JScrollPane(Txt5));

        Txt2 = new JTextArea(38, 32);
        Txt2.setEditable(false);
        Txt2.setLineWrap(true);
        Txt2.setWrapStyleWord(true);
        Txt2.setFont(new Font("Calibri", Font.PLAIN, 16));
        Txt2.append("Connections:\n\n");
        eastPanel.add(new JScrollPane(Txt2));
        JPanel pCol = new JPanel();
        pCol.setBackground(Color.decode("#90989E"));
        tabPane1.add((pCol),BorderLayout.SOUTH);
        tabPane1.add(westPanel,BorderLayout.LINE_START);
        tabPane1.add(eastPanel,BorderLayout.CENTER);

        tabbedPane.addTab("Check-In",tabPane);
        tabbedPane.addTab("Room Config",tabPane1);
        tabbedPane.addTab("Cleaning Service",tabPane2);
        tabbedPane.addTab("Restaurant Service",tabPane3);
        tabbedPane.addTab("Entertainment",tabPane4);


        confirm.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String password = pWord.getText();
                String room =rn.getText();

                if(room.equals("431")){
                    room431Pword = room+" "+password;
                    Pword431=password;
                    appRoom431 = "roomPWORD431"+" "+password;
                    System.out.println("Confirm Room 431:"+room431Pword);
                }else if(room.equals("436")){
                    room436Pword=room+" "+password;
                    Pword436=password;
                    appRoom436 = "roomPWORD436"+" "+password;
                    System.out.println("Confirm Room 436:"+room436Pword);
                }else if(room.equals("593")){
                    room593Pword=room +" "+password;
                    Pword593=password;
                    appRoom593 = "roomPWORD593"+" "+password;
                    System.out.println("Confirm Room 593:"+room593Pword);
                }
                //String RoomPassword = room +" ,"+password;
                System.out.println("appID: "+appID);
                pWord.setText("");
                rn.setText("");
                //CST[appID].SendData("R"+RoomPassword);
            }
        });

        Clear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Txt1.setText("");
                Txt1.append("Status:\t\tDate:              Time:\n\n");
            }
        });

        DoorLock.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                javax.swing.SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        RoomLockGUI();
                    }
                });
            }
        });

        Database.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                javax.swing.SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        //Database.setEnabled(false);

                        DatabaseGUI();
                    }
                });
            }
        });

        RoomNo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                javax.swing.SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        RoomNoGUI();
                    }
                });
            }
        });
        //**********************************************  TAB CLEANED*****************************************************************
        P2_Txt1 = new JTextArea(38, 28);
        P2_Txt1.setEditable(false);
        P2_Txt1.setLineWrap(true);
        P2_Txt1.setWrapStyleWord(true);
        P2_Txt1.append("ID\tDate:\t\tService:\t\t     Room:\t\t       Time:\t\t       Extra Pillows:\t\tExtra Towels:\n\n");
        P2_Txt1.setFont(new Font("Calibri", Font.PLAIN, 16));
        //p2_label=new JLabel("\n");
        p2_label=new JLabel("<html>CLEANING SERVICE<br></html>", SwingConstants.CENTER);
        p2_label.setFont(new Font("Calibri", Font.BOLD, 30));
        JPanel tabpanel2=new JPanel(new FlowLayout());
        JLabel number = new JLabel("Room Cleaned(ID)");
        number.setFont(new Font("Calibri", Font.BOLD, 26));
        JTextField CleanedNum = new JTextField(6);
        CleanedNum.setFont(new Font("Calibri", Font.PLAIN, 24));
        JButton cleaned = new JButton("Confirm");
        cleaned.setFont(new Font("Calibri", Font.PLAIN, 24));
        tabpanel2.add(number);
        tabpanel2.add(CleanedNum);
        tabpanel2.add(cleaned);
        //tabPane2.setBackground(Color.decode("#90989E"));
        tabPane2.add(p2_label,BorderLayout.NORTH);
        tabPane2.add(new JScrollPane(P2_Txt1),BorderLayout.CENTER);
        tabPane2.add(new JScrollPane(tabpanel2),BorderLayout.SOUTH);

        cleaned.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String numCleaned = CleanedNum.getText();
                int lineNumber = Integer.parseInt(numCleaned.trim());
                try {
                    if(lineNumber==0){
                        lineNumber = lineNumber+2;
                    }else{
                        lineNumber=lineNumber+lineNumber+2;
                    }
                    Highlighter.HighlightPainter painter;
                    int startIndex = P2_Txt1.getLineStartOffset(lineNumber);
                    int endIndex = P2_Txt1.getLineEndOffset(lineNumber);
                    painter = new DefaultHighlighter.DefaultHighlightPainter(Color.RED);
                    P2_Txt1.getHighlighter().addHighlight(startIndex, endIndex, painter);
                }catch (Exception i){

                }

            }
        });
        //******************************************** TAB RESTAURANT *******************************************************************

        JLabel title = new JLabel("RESTAURANT SERVICE");
        title.setFont(new Font("Calibri", Font.BOLD, 30));
        tabPane3.add ( title,"span,center,wrap");
        display = new JTextArea ( 16, 70 );
        display.setEditable ( false ); // set textArea non-editable
        JScrollPane scroll = new JScrollPane ( display);
        scroll.setVerticalScrollBarPolicy ( ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS );
        tabPane3.add ( scroll,"span,center,wrap");
        display.append("ID\t\tROOM NUMBER\t\tTIME\t\tTABLE FOR\n\n");

        JLabel lab = new JLabel("ID:");
        lab.setFont(new Font("Calibri", Font.BOLD, 26));
        JTextField t = new JTextField(6);
        t.setFont(new Font("Calibri", Font.PLAIN, 24));
        JButton but = new JButton("ADD");
        but.setFont(new Font("Calibri", Font.BOLD, 26));
        tabPane3.add(lab,"span, split 3, center");
        tabPane3.add(t);
        tabPane3.add(but,"span,wrap");

        JLabel l = new JLabel("Room:");
        l.setFont(new Font("Calibri", Font.BOLD, 26));
        JTextField roomt = new JTextField(6);
        roomt.setFont(new Font("Calibri", Font.PLAIN, 24));
        roomt.setEditable ( false ); // set textArea non-editable
        JLabel tim = new JLabel("Time:");
        tim.setFont(new Font("Calibri", Font.BOLD, 26));
        JTextField roomtime = new JTextField(6);
        roomtime.setFont(new Font("Calibri", Font.PLAIN, 24));
        roomtime.setEditable ( false ); // set textArea non-editable
        JLabel Table = new JLabel("Table For:");
        Table.setFont(new Font("Calibri", Font.BOLD, 26));
        JTextField tableamount = new JTextField(6);
        tableamount.setEditable ( false ); // set textArea non-editable
        tableamount.setFont(new Font("Calibri", Font.PLAIN, 24));
        tabPane3.add(l,"span, split 6, center");
        tabPane3.add(roomt);
        tabPane3.add(tim);
        tabPane3.add(roomtime);
        tabPane3.add(Table);
        tabPane3.add(tableamount,"wrap");

        JButton Rbutton1= new JButton("CONFIRM");
        Rbutton1.setFont(new Font("Calibri", Font.BOLD, 26));
        JButton Rbutton2= new JButton("DECLINE");
        Rbutton2.setFont(new Font("Calibri", Font.BOLD, 26));
        tabPane3.add(Rbutton1,"span, split 2, center");
        tabPane3.add(Rbutton2,"center,wrap");

        but.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String RoomRest = t.getText();
                int lineNumber = Integer.parseInt(RoomRest);
                try {
                    if(lineNumber==0){
                        lineNumber = lineNumber+2;
                    }else{
                        lineNumber=lineNumber+lineNumber+2;
                    }

                    startIndexRest = display.getLineStartOffset(lineNumber);
                    endIndexRest = display.getLineEndOffset(lineNumber);
                    //painter = new DefaultHighlighter.DefaultHighlightPainter(Color.CYAN);
                    //display.getHighlighter().addHighlight(startIndexRest, endIndexRest, painter);
                    String restString = display.getText().substring(startIndexRest,endIndexRest);
                    String[]parts = restString.split("\\s+");
                    roomt.setText(""+parts[1]);
                    roomtime.setText(""+parts[2]);
                    tableamount.setText(""+parts[3]);
                }catch (Exception i){

                }

            }
        });
        Rbutton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                try{
                    painter = new DefaultHighlighter.DefaultHighlightPainter(Color.GREEN);
                    display.getHighlighter().addHighlight(startIndexRest, endIndexRest, painter);
                    String room = roomt.getText().toString();
                    String restTime = roomtime.getText().toString();
                    String people = tableamount.getText().toString();
                    String notificationTrue = "NotificationTrue "+room+" "+restTime+" "+people;
                    CST[appID].SendData(notificationTrue);

                }catch (Exception x){

                }

            }
        });

        Rbutton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                try{
                    painter = new DefaultHighlighter.DefaultHighlightPainter(Color.RED);
                    display.getHighlighter().addHighlight(startIndexRest, endIndexRest, painter);
                    String room = roomt.getText().toString();
                    String restTime = roomtime.getText().toString();
                    String people = tableamount.getText().toString();
                    String notificationFalse = "NotificationFalse "+room+" "+restTime+" "+people;
                    CST[appID].SendData(notificationFalse);
                }catch (Exception x){

                }

            }
        });
        //**********************************************  TAB ENTERTAINMENT*****************************************************************

        JLabel entertain=new JLabel("<html>Tonights Entertainment<br></html>", SwingConstants.CENTER);
        entertain.setFont(new Font("Calibri", Font.BOLD, 30));
        JPanel enterPanel = new JPanel(new GridLayout(10,1));
        EntertainmentName=new JLabel("<html>"+EntName+"<br></html>", SwingConstants.CENTER);
        EntertainmentName.setFont(new Font("Calibri", Font.BOLD, 24));
        JLabel EntertainmentTime=new JLabel("<html>N/A<br></html>", SwingConstants.CENTER);
        EntertainmentTime.setFont(new Font("Calibri", Font.BOLD, 24));
        JLabel EntertainmentLocation=new JLabel("<html>N/A<br></html>", SwingConstants.CENTER);
        EntertainmentLocation.setFont(new Font("Calibri", Font.BOLD, 24));

        JPanel namePanel = new JPanel(new GridLayout(1,8));
        JLabel bandName = new JLabel("Name: ");
        bandName.setFont(new Font("Calibri", Font.PLAIN, 24));
        JTextArea bandNameTA = new JTextArea(1,10);
        bandNameTA.setFont(new Font("Calibri", Font.PLAIN, 24));
        namePanel.add(new JLabel());
        //namePanel.add(new JLabel());
        namePanel.add(new JLabel());
        namePanel.add(bandName);
        namePanel.add(bandNameTA);
        namePanel.add(new JLabel());
       // namePanel.add(new JLabel());
        namePanel.add(new JLabel());

        JPanel timePanel = new JPanel(new GridLayout(1,8));
        JLabel bandTime = new JLabel("Time: ");
        bandTime.setFont(new Font("Calibri", Font.PLAIN, 24));
        JTextArea bandTimeTA = new JTextArea(1,6);
        bandTimeTA.setFont(new Font("Calibri", Font.PLAIN, 24));
        timePanel.add(new JLabel());
       // timePanel.add(new JLabel());
        timePanel.add(new JLabel());
        timePanel.add(bandTime);
        timePanel.add(bandTimeTA);
       // timePanel.add(new JLabel());
        timePanel.add(new JLabel());
        timePanel.add(new JLabel());

        JPanel locationPanel = new JPanel(new GridLayout(1,7));
        JLabel bandLocation = new JLabel("Location: ");
        bandLocation.setFont(new Font("Calibri", Font.PLAIN, 24));
        JTextArea bandLocationTA = new JTextArea(1,10);
        bandLocationTA.setFont(new Font("Calibri", Font.PLAIN, 24));
        locationPanel.add(new JLabel());
        locationPanel.add(new JLabel());
        //locationPanel.add(new JLabel());
        locationPanel.add(bandLocation);
        locationPanel.add(bandLocationTA);
        locationPanel.add(new JLabel());
        locationPanel.add(new JLabel());
        //locationPanel.add(new JLabel());

        JPanel updatePanel = new JPanel(new FlowLayout());
        JButton updateEnter = new JButton("UPDATE ");
        updateEnter.setFont(new Font("Calibri", Font.BOLD, 24));
        updatePanel.add(updateEnter);

        enterPanel.add(EntertainmentName);
        enterPanel.add(EntertainmentTime);
        enterPanel.add(EntertainmentLocation);
        enterPanel.add(namePanel);
        enterPanel.add(timePanel);
        enterPanel.add(locationPanel);
        enterPanel.add(updatePanel);
        tabPane4.add(entertain,BorderLayout.NORTH);
        tabPane4.add(enterPanel,BorderLayout.CENTER);

        updateEnter.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                EntertainmentName.setText(bandNameTA.getText().toString());
                EntertainmentLocation.setText(bandLocationTA.getText().toString());
                EntertainmentTime.setText(bandTimeTA.getText().toString());
                bandNameTA.setText("");
                bandLocationTA.setText("");
                bandTimeTA.setText("");
                AndroidEntertainment = " $"+EntertainmentName.getText().toString()+" $"+EntertainmentTime.getText().toString()+" $"+EntertainmentLocation.getText().toString();
            }
        });
        //**********************************************  DISPLAY GUI*****************************************************************
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setUndecorated(true);
        frame.add(tabbedPane);
        frame.setVisible(true);
        Socket();
    }
    /*****************************************************************************************************
     *Gui that connects to the K64f
     ****************************************************************************************************/
    private void RoomLockGUI(){
        JFrame frame3 = new JFrame("Lock Room");
        frame3.setSize(350,140);
        JPanel upperPanel = new JPanel();
        JPanel lowerPanel = new JPanel();
        JPanel centerPanel = new JPanel();
        frame3.getContentPane().add(upperPanel, "North");
        frame3.getContentPane().add(centerPanel, "Center");
        frame3.getContentPane().add(lowerPanel, "South");
        upperPanel.setSize(500,100);
        upperPanel.setLayout(new FlowLayout());
        centerPanel.setSize(500,100);
        centerPanel.setLayout(new FlowLayout());
        lowerPanel.setSize(500,100);
        lowerPanel.setLayout(new BorderLayout());
        RLText = new JTextField("");
        RLText =new JTextField(5);
        RLText.setEditable(true);
        //RLText.setLineWrap(true);
        //RLText.setWrapStyleWord(true);
        label = new JLabel("Room No.*");
        Lock = new JButton("Lock");
        unLock = new JButton("Unlock");
        CleanerLock=new JButton("Cleaner Lock");
        ErrorText = new JTextField("");
        ErrorText=new JTextField(5);
        ErrorText.setEditable(false);
        //ErrorText.setLineWrap(true);
        //ErrorText.setWrapStyleWord(true);
        upperPanel.setBackground(Color.decode("#90989E"));
        centerPanel.setBackground(Color.decode("#90989E"));
        lowerPanel.setBackground(Color.decode("#90989E"));
        upperPanel.add(label);
        upperPanel.add(RLText);
        centerPanel.add(Lock);
        centerPanel.add(CleanerLock);
        centerPanel.add(unLock);
        lowerPanel.add(ErrorText,BorderLayout.SOUTH);
        frame3.setVisible(true);
        Lock.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String Result = RLText.getText().toString();

                if(number431.equals(Result)){
                    CST[room431ID].SendData("Lock..");
                    RLText.setText("");
                    ErrorText.setText("Room Locked");
                    Txt5.append("Room Number "+number431 +" Locked\n\n");
                    frame3.setVisible(false);
                    frame3.dispose();
                }else if(number436.equals(Result)){
                    CST[room436ID].SendData("Lock..");
                    RLText.setText("");
                    ErrorText.setText("Room Locked");
                    Txt5.append("Room Number "+number436 +" Locked\n\n");
                    frame3.setVisible(false);
                    frame3.dispose();
                }else if(number593.equals(Result)){
                    CST[room593ID].SendData("Lock..");
                    RLText.setText("");
                    ErrorText.setText("Room Locked");
                    Txt5.append("Room Number "+number593 +" Locked\n\n");
                    frame3.setVisible(false);
                    frame3.dispose();
                }else{
                    ErrorText.setText("Invaild Room Number");
                    RLText.setText("");
                }
            }
        });
        CleanerLock.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String Result = RLText.getText().toString();

                if(number431.equals(Result)){
                    CST[room431ID].SendData("LockClean..");
                    RLText.setText("");
                    ErrorText.setText("Room Locked From Cleaner");
                    Txt5.append("Room Number "+number431 +" Locked From Cleaner\n\n");
                    frame3.setVisible(false);
                    frame3.dispose();
                }else if(number436.equals(Result)){
                    CST[room436ID].SendData("LockClean..");
                    RLText.setText("");
                    ErrorText.setText("Room Locked From Cleaner");
                    Txt5.append("Room Number "+number436 +" Locked From Cleaner\n\n");
                    frame3.setVisible(false);
                    frame3.dispose();
                }else if(number593.equals(Result)){
                    CST[room593ID].SendData("LockClean..");
                    RLText.setText("");
                    ErrorText.setText("Room Locked From Cleaner");
                    Txt5.append("Room Number "+number593 +" Locked From Cleaner\n\n");
                    frame3.setVisible(false);
                    frame3.dispose();
                }else{
                    ErrorText.setText("Invaild Room Number");
                    RLText.setText("");
                }
            }
        });
        unLock.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String Result = RLText.getText().toString();

                if(number431.equals(Result)){
                    CST[room431ID].SendData("UnLocked..");
                    RLText.setText("");
                    ErrorText.setText("Room Unlocked");
                    Txt5.append("Room Number "+number431 +" Unlocked\n\n");
                    frame3.setVisible(false);
                    frame3.dispose();
                }else if(number436.equals(Result)){
                    CST[room436ID].SendData("UnLocked..");
                    RLText.setText("");
                    ErrorText.setText("Room Unlocked");
                    Txt5.append("Room Number "+number436 +" Unlocked\n\n");
                    frame3.setVisible(false);
                    frame3.dispose();
                }else if(number593.equals(Result)){
                    CST[room593ID].SendData("UnLocked..");
                    RLText.setText("");
                    ErrorText.setText("Room Unlocked");
                    Txt5.append("Room Number "+number593 +" Unlocked\n\n");
                    //Txt5.append(number593 +" Unlocked");
                    RLText.setText("");
                    frame3.setVisible(false);
                    frame3.dispose();
                }else{
                    ErrorText.setText("Invaild Room Number");
                    RLText.setText("");
                }
            }
        });

    }
    /*****************************************************************************************************
     *Gui that displays the contents of the Database
     ****************************************************************************************************/
    private void DatabaseGUI(){
        JFrame frame2 = new JFrame("Database Search");

        frame2.setSize(1390,768);

        JPanel upperPanel = new JPanel();
        JPanel lowerPanel = new JPanel();
        frame2.getContentPane().add(upperPanel, "North");
        frame2.getContentPane().add(lowerPanel, "South");
        upperPanel.setSize(500,100);
        upperPanel.setLayout(new FlowLayout());
        DSText = new JTextField("");
        DSText=new JTextField(5);
        DSText.setEditable(true);
        //DSText.setLineWrap(true);
        //DSText.setWrapStyleWord(true);

        DataSearch = new JButton("Search Database");
        upperPanel.add(DataSearch);
        upperPanel.add(DSText);
        upperPanel.setBackground(Color.red);
        lowerPanel.setBackground(Color.decode("#90989E"));
        Txt3 = new JTextArea(30, 30);
        Txt3.setEditable(false);
        Txt3.setLineWrap(true);
        Txt3.setWrapStyleWord(true);
        Txt3.setFont(new Font("Calibri", Font.PLAIN, 16));
        Txt3.append("Contents of Database:\n");
        Txt3.append("Status:\t\tDate:              Time:\n\n");
        lowerPanel.add(new JScrollPane(Txt3));

        Txt4 = new JTextArea(30, 30);
        Txt4.setEditable(false);
        Txt4.setLineWrap(true);
        Txt4.setWrapStyleWord(true);
        Txt4.setFont(new Font("Calibri", Font.PLAIN, 16));
        Txt4.append("Search Results:\nStatus:\t\tDate:              Time:\n\n");
        lowerPanel.add(new JScrollPane(Txt4));
        frame2.pack();
        frame2.setVisible(true);
        DatabaseSearch();
        DataSearch.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String search = DSText.getText();
                Txt4.setText("");
                Txt4.append("Search Results:\nStatus:\t\tDate:              Time:\n\n");
                String[] lines = Txt3.getText().split("\\n");
                for(int i = 0 ; i< lines.length; i++) {
                    if(lines[i].contains(search)) {
                        Txt4.append(lines[i] + "\n");
                    }
                }

            }
        });

    }
    /*****************************************************************************************************
     *Gets the Contents of everything that is stored in the Database
     ****************************************************************************************************/
    public void DatabaseSearch() {
        (new dataSearch()).execute();
    }
    class dataSearch extends SwingWorker<Void, String> {
        @Override
        protected Void doInBackground() throws Exception {
            try {
                System.out.print("Database");
                String myDriver = "com.mysql.jdbc.Driver";
                Class.forName(myDriver);
                conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "");


                Statement statement = conn.createStatement();

                // query database
                ResultSet resultSet = statement.executeQuery( "SELECT * FROM hotel" );

                // process query results
                StringBuffer results = new StringBuffer();
                ResultSetMetaData metaData = resultSet.getMetaData();
                int numberOfColumns = metaData.getColumnCount();

                for ( int i = 4; i <= numberOfColumns; i++ ) {
                    results.append( metaData.getColumnName( i )
                            + "\t\t" );
                }
                results.append( "" );
                while ( resultSet.next() ) {
                    for ( int i = 2; i <= numberOfColumns; i++ ) {
                        results.append( resultSet.getObject( i )
                                + "\t\t" );
                    }
                    results.append( "\n" );
                }
                Txt3.append(results+"");
                statement.close();

            }catch(Exception io){}
            return null;
        }
    }
    /*****************************************************************************************************
     *
     ****************************************************************************************************/
    private void RoomNoGUI(){
        JFrame frame3 = new JFrame("Room No. Change");
        frame3.setSize(350,160);
        JPanel upperPanel = new JPanel();
        JPanel lowerPanel = new JPanel();
        JPanel centerPanel = new JPanel();
        frame3.getContentPane().add(upperPanel, "North");
        frame3.getContentPane().add(centerPanel, "Center");
        frame3.getContentPane().add(lowerPanel, "South");
        upperPanel.setSize(500,100);
        upperPanel.setLayout(new GridLayout(2,2));
        centerPanel.setSize(500,100);
        centerPanel.setLayout(new FlowLayout());
        lowerPanel.setSize(500,100);
        lowerPanel.setLayout(new BorderLayout());
        RoomNoText = new JTextField("");
        RoomNoText =new JTextField(5);
        RoomNoText.setEditable(true);
        //RoomNoText.setLineWrap(true);
        //RoomNoText.setWrapStyleWord(true);
        upperPanel.setBackground(Color.decode("#90989E"));
        centerPanel.setBackground(Color.decode("#90989E"));
        lowerPanel.setBackground(Color.decode("#90989E"));
        CText = new JTextField("");
        CText =new JTextField(5);
        CText.setEditable(true);
        //CText.setLineWrap(true);
        //CText.setWrapStyleWord(true);

        labelR = new JLabel("Room No.*");
        labelC = new JLabel("Change To");

        UpdateChange = new JButton("Update Change");


        ErrorText = new JTextField("");
        ErrorText=new JTextField(5);
        ErrorText.setEditable(false);
        //ErrorText.setLineWrap(true);
        //ErrorText.setWrapStyleWord(true);

        upperPanel.add(labelR);
        upperPanel.add(RoomNoText);
        upperPanel.add(labelC);
        upperPanel.add(CText);
        centerPanel.add(UpdateChange);

        lowerPanel.add(ErrorText,BorderLayout.SOUTH);
        frame3.setVisible(true);
        UpdateChange.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String RoomNo = RoomNoText.getText().toString();
                String RoomNoChange = CText.getText().toString();
                int num= Integer.parseInt(RoomNoChange);
                if(RoomNo.equals(RoomNoChange)){
                    ErrorText.setText("Both Number are the Same");
                }
                else {
                    if (number431.equals(RoomNo)) {
                        if (num > 0) {
                            CST[room431ID].SendData(RoomNoChange + "");
                            ErrorText.setText("Room Updated");
                            RoomNoText.setText("");
                            Txt5.append("Room Number Changed From "+number431 +" to "+RoomNoChange+"\n\n");
                            clientCount = 0;
                            frame3.setVisible(false);
                            frame3.dispose();
                        } else {
                            ErrorText.setText("Enter Correct Room Number");
                            RoomNoText.setText("");
                        }
                    }else if (number436.equals(RoomNo)) {
                        if (num > 0) {
                            CST[room436ID].SendData(RoomNoChange + "");
                            ErrorText.setText("Room Updated");
                            RoomNoText.setText("");
                            Txt5.append("Room Number Changed From "+number436 +" to "+RoomNoChange+"\n\n");
                            clientCount = 0;
                            frame3.setVisible(false);
                            frame3.dispose();
                        } else {
                            ErrorText.setText("Enter Correct Room Number");
                            RoomNoText.setText("");
                        }
                    }else if (number593.equals(RoomNo)) {
                        if (num > 0) {
                            CST[room593ID].SendData(RoomNoChange + "");
                            ErrorText.setText("Room Updated");
                            RoomNoText.setText("");
                            Txt5.append("Room Number Changed From "+number593 +" to "+RoomNoChange+"\n\n");
                            clientCount = 0;
                            frame3.setVisible(false);
                            frame3.dispose();
                        } else {
                            ErrorText.setText("Enter Correct Room Number");
                            RoomNoText.setText("");
                        }
                    } else {
                        ErrorText.setText("Invaild Room Number");
                        RoomNoText.setText("");
                    }
                }
            }
        });
    }
    /*****************************************************************************************************
     *
     ****************************************************************************************************/
    public void Socket() {
        (new Sock()).execute();
    }
    class Sock extends SwingWorker<Void, String> {
        @Override
        protected Void doInBackground() throws Exception {
            ServerSocket m_ServerSocket = new ServerSocket(12345);

            CST = new ClientServiceThread[50];
            for(id=0;id<50;id++) {
                clientCount=0;
                System.out.println("...1...");
                Socket clientSocket = m_ServerSocket.accept();
                CST[id] = new ClientServiceThread(clientSocket, id);
                CST[id].start();
            }
            return null;
        }
    }
    /*****************************************************************************************************
     *
     ****************************************************************************************************/
    class ClientServiceThread extends Thread {
        Socket clientSocket;
        int clientID = -1;
        boolean running = true;
        int count=0;

        ClientServiceThread(Socket s, int i) {
            clientSocket = s;
            clientID = i;
        }

        public void run() {
            System.out.println("Accepted Client : ID - " + clientID + " : Address - " + clientSocket.getInetAddress().getHostName());
            try {
                BufferedReader   in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                while (running) {

                    String date_time = new SimpleDateFormat("yyyy/MM/dd   HH:mm:ss").format(Calendar.getInstance().getTime());
                    count++;
                    String clientCommand = in.readLine();
                    System.out.println("Client Says :" + clientCommand + room431Pword);
                    /***************************************************************************************************
                     * Commands that are recieved from the K64 board
                     **************************************************************************************************/

                    if (clientCommand.equalsIgnoreCase("quit")) {
                        running = false;
                    }else if(clientCommand.equals("431") && clientCount==0){
                        if(room436ID==clientID){
                            System.out.println("Changing client id");
                            room436ID=-1;
                        }else if(room593ID==clientID){
                            room593ID=-1;
                        }
                        room431ID=clientID;
                        BoardRNum=clientCommand;
                        Txt2.append("Room " + clientCommand + " is Connected\n\n");
                        System.out.print("Connected" + clientCommand);
                        //number431 = clientCommand;
                        clientCount++;

                    }else if(clientCommand.equals("436") && clientCount==0){
                        if(room431ID==clientID){
                            System.out.println("Changing client id");
                            room431ID=-1;
                        }else if(room593ID==clientID){
                            room593ID=-1;
                        }
                        room436ID=clientID;
                        BoardRNum=clientCommand;
                        Txt2.append("Room " + clientCommand + " is Connected\n\n");
                        System.out.print("Connected" + clientCommand);
                        //number436 = clientCommand;
                        clientCount++;
                    }else if(clientCommand.equals("593") && clientCount==0){
                        if(room431ID==clientID){
                            System.out.println("Changing client id");
                            room431ID=-1;
                        }else if(room431ID==clientID){
                            room431ID=-1;
                        }
                        room593ID=clientID;
                        BoardRNum=clientCommand;
                        Txt2.append("Room " + clientCommand + " is Connected\n\n");
                        System.out.print("Connected" + clientCommand);
                        //number593 = clientCommand;
                        clientCount++;
                    }
                    if(clientCommand.equals("Cleaning")){
                        Txt1.append("Master Scanned"+"\t" +date_time+"\n\n");
                        Database("Master",date_time);
                    }

                    if(clientCommand.contains("en "+Pword431+"431")){
                        CST[room431ID].SendData("TRUE");
                        Txt1.append("431" +" Scanned"+"\t\t" +date_time+"\n\n");
                        Database("431",date_time);
                    }else if(clientCommand.contains("en "+Pword436+"436")){
                        CST[room436ID].SendData("TRUE");
                        Txt1.append("436" +" Scanned"+"\t\t" +date_time+"\n\n");
                        Database("436",date_time);
                    }else if(clientCommand.contains("en "+Pword593+"593")){
                        CST[room593ID].SendData("TRUE");
                        Txt1.append("593" +" Scanned"+"\t\t" +date_time+"\n\n");
                        Database("593",date_time);
                    }else if(clientCommand.startsWith("en") && clientCommand.contains("593")){
                        CST[room593ID].SendData("FALSE");
                    }else if(clientCommand.startsWith("en") && clientCommand.contains("431")){
                        CST[room431ID].SendData("FALSE");
                    }else if(clientCommand.startsWith("en") && clientCommand.contains("436")){
                        CST[room436ID].SendData("FALSE");
                    }
                    /***************************************************************************************************
                     * Commands that are recieved from the Android App
                     **************************************************************************************************/
                    if(clientCommand.contains("App")){
                        Txt2.append(clientCommand +"\n\n");

                    } else if(clientCommand.contains("Password")){
                        appID=clientID;
                        CST[appID].SendData("connected");
                        clientCount++;
                    } else if(clientCommand.contains("Cleaning Service ")){
                        clientCount++;
                        if(clientCommand.contains(room1)){//room1 =436
                            int r1 = Integer.parseInt(room1);
                            int br1 = Integer.parseInt(BoardRNum);
                            System.out.print("Room 1;"+r1+".."+room436ID);
                            if(r1==br1){
                                CST[room436ID].SendData("UnLocked..");
                                System.out.print("Room 1 clean");
                            }
                        }else if(clientCommand.contains(room2)){//room2 =593
                            int r1 = Integer.parseInt(room2);
                            int br1 = Integer.parseInt(BoardRNum);
                            System.out.print("Room 2;"+r1+".."+room593ID);
                            if(r1==br1){
                                CST[room593ID].SendData("UnLocked..");
                                System.out.print("Room 2 clean");
                            }
                        }else if(clientCommand.contains(room3)){//room3 =431
                            int r1 = Integer.parseInt(room3);
                            int br1 = Integer.parseInt(BoardRNum);
                            System.out.print("Room 3;"+r1+".."+room431ID);
                            if(r1==br1){
                                CST[room431ID].SendData("UnLocked..");
                                System.out.print("Room 3 clean");
                            }
                        }
                        String date = new SimpleDateFormat("yyyy/MM/dd").format(Calendar.getInstance().getTime());
                        P2_Txt1.append(lineNumber+"\t"+date+clientCommand+"\n\n");
                        lineNumber++;
                    }//End Cleaning Service
                    /***************************************************************************************************
                     * App sends the room number and password and if they are correct the server returns true to the
                     * app to allow access.
                     **************************************************************************************************/
                    if (clientCommand.equals(room431Pword)){
                        CST[appID].SendData("TRUE");
                    }else if(clientCommand.startsWith("431 ")){
                        CST[appID].SendData("FALSE");
                    }else if(clientCommand.equals(room436Pword)){
                        CST[appID].SendData("TRUE");
                    }else if(clientCommand.startsWith("436 ")){
                        CST[appID].SendData("FALSE");
                    }else if(clientCommand.equals(room593Pword)){
                        CST[appID].SendData("TRUE");
                    }else if(clientCommand.startsWith("593 ")){
                        CST[appID].SendData("FALSE");
                    }
                    /***************************************************************************************************
                     *App sends Details for restaurant booking
                     ***************************************************************************************************/
                    if (clientCommand.startsWith("Restaurant 431")){

                        String[] stringspl = clientCommand.split("\\s+");
                        String restaurantDisp = restCount+"\t\t"+stringspl[1]+"\t\t\t"+stringspl[2]+"\t\t"+stringspl[3];
                        display.append(restaurantDisp+"\n\n");
                        restCount++;
                    }else if (clientCommand.startsWith("Restaurant 436")){

                        String[] stringspl = clientCommand.split("\\s+");
                        String restaurantDisp = restCount+"\t\t"+stringspl[1]+"\t\t\t"+stringspl[2]+"\t\t"+stringspl[3];
                        display.append(restaurantDisp+"\n\n");
                        restCount++;
                    }else if (clientCommand.startsWith("Restaurant 593")){

                        String[] stringspl = clientCommand.split("\\s+");
                        String restaurantDisp = restCount+"\t\t"+stringspl[1]+"\t\t\t"+stringspl[2]+"\t\t"+stringspl[3];
                        display.append(restaurantDisp+"\n\n");
                        restCount++;
                    }else
                    /***************************************************************************************************
                    *App sents request to unlock the door. if the password entered is correct return true
                    ***************************************************************************************************/
                    if(clientCommand.equals(appRoom431)){
                        //appID = clientID;
                        CST[appID].SendData("roomtrue");
                        System.out.print("....TRUE.....");
                        CST[room431ID].SendData("apptrue");
                        Txt1.append("431" +" App Unlock"+"\t" +date_time+"\n\n");
                    }else if(clientCommand.equals(appRoom436) ){
                        //appID = clientID;
                        CST[appID].SendData("roomtrue");
                        System.out.print("....TRUE.....");
                        CST[room436ID].SendData("apptrue");
                        Txt1.append("436" +" App Unlock"+"\t" +date_time+"\n\n");
                    }else if(clientCommand.equals(appRoom593) ){
                        //appID = clientID;
                        CST[appID].SendData("roomtrue");
                        System.out.print("....TRUE.....");
                        CST[room593ID].SendData("apptrue");
                        Txt1.append("593" +" App Unlock"+"\t" +date_time+"\n\n");
                    }else if(clientCommand.contains("roomPWORD431") || clientCommand.contains("roomPWORD436") ||clientCommand.contains("roomPWORD593")){
                        //appID = clientID;
                        CST[appID].SendData("roomfalse");
                        System.out.print("....FALSE.....");
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        /*****************************************************************************************************
         *Sends a String of data to the guests Bedroom(K64F) or the Android App
         ****************************************************************************************************/
        private void SendData(String s){
            try {
                PrintWriter out = new PrintWriter(new OutputStreamWriter(clientSocket.getOutputStream()));
                System.out.print("Send data: "+ s);
                out.println(s);
                out.flush();
            }catch(IOException io){

            }
        }
        /*****************************************************************************************************
         *Sends all key scans to be saved in a mySQL database
         ****************************************************************************************************/
        private void Database(String card,String DT){
            try {

                String myDriver = "com.mysql.jdbc.Driver";
                Class.forName(myDriver);
                conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "");

                String query = " insert into hotel (card_scanned, date_time)" + " values (?, ?)";

                PreparedStatement preparedStmt = conn.prepareStatement(query);
                preparedStmt.setString (1,card );
                preparedStmt.setString (2, DT);
                preparedStmt.execute();
                conn.close();
                System.out.print("Connection Closed\r\n");
            }catch(Exception io){

            }
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////
}