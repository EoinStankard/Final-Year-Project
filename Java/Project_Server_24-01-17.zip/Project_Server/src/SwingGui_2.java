/**
 * Created by h on 29/11/2016.
 */

import java.awt.event.KeyEvent;
import java.io.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.ServerSocket;
import java.net.Socket;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;


public class SwingGui_2{
    JTextArea Txt1,Txt2,Txt3,Txt4,Txt5, RLText,DSText,ErrorText,CText,RoomNoText;
    JButton DoorLock,Database,Clear,unLock,Lock,DataSearch,CleanerLock,RoomNo,UpdateChange;
    JLabel label,labelR,labelC;
    String number;
    ClientServiceThread[] CST;
    Connection conn;
    int clientCount=0;
    JTabbedPane tabbedPane = new javax.swing.JTabbedPane();

    int id;
    int roomID;
    public static void main(String[] args) {
        try{
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");


        }
        catch(Exception ex ){
            ex.printStackTrace();

        }
        new SwingGui_2();
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    public SwingGui_2() {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {

                GUI();
            }
        });
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    private void GUI() {
        JFrame frame = new JFrame("Hotel Server");
        frame.setSize(1372,738);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel westPanel = new JPanel();
        JPanel eastPanel = new JPanel();
        JPanel northPanel = new JPanel();

        frame.getContentPane().add(northPanel, "North");
        frame.getContentPane().add(westPanel, "West");
        frame.getContentPane().add(eastPanel, "Center");
       // eastPanel.setSize(800,100);
        eastPanel.setLayout(new FlowLayout());
        eastPanel.setBackground(Color.decode("#90989E"));
        //westPanel.setSize(800,100);
        westPanel.setLayout(new GridLayout(10,1));
        JLabel Header =new JLabel("Automated Hotel\n");
        Clear = new JButton("Clear");
        Database = new JButton("Database");
        DoorLock = new JButton("Lock/Unlock Room");
        RoomNo = new JButton("Room No.");
        //JButton Search = new JButton("Search");

        //tabbedPane.add("Tab1",westPanel);

        westPanel.add(Clear);
        westPanel.add(Database);
        westPanel.add(DoorLock);
        westPanel.add(RoomNo);
        westPanel.setBackground(Color.decode("#90989E"));
        Header.setFont(new Font("Calibri", Font.ITALIC, 32));
        northPanel.add(Header);
        northPanel.setBackground(Color.red);

        //upperPanel.add(Search);
        Txt1 = new JTextArea(38, 28);
        Txt1.setEditable(false);
        Txt1.setLineWrap(true);
        Txt1.setWrapStyleWord(true);
        Txt1.append("Status:\t\tDate:              Time:\n\n");
        eastPanel.add(new JScrollPane(Txt1));
        Txt5 = new JTextArea(38, 28);
        Txt5.setEditable(false);
        Txt5.setLineWrap(true);
        Txt5.setWrapStyleWord(true);
        Txt5.append("Room Config:\n\n");
        eastPanel.add(new JScrollPane(Txt5));

        Txt2 = new JTextArea(38, 28);
        Txt2.setEditable(false);
        Txt2.setLineWrap(true);
        Txt2.setWrapStyleWord(true);
        Txt2.append("Connections:\n\n");
        eastPanel.add(new JScrollPane(Txt2));

        //frame.pack();
        //frame.add(tabbedPane);
        frame.setVisible(true);
        Socket();
        Clear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Txt1.setText("");
                Txt1.append("Status:\t\tDate:              Time:\n\n");
            }
        });

        DoorLock.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                javax.swing.SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        RoomLockGUI();
                    }
                });
            }
        });

        Database.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                javax.swing.SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        //Database.setEnabled(false);

                        DatabaseGUI();
                    }
                });
            }
        });

        RoomNo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                javax.swing.SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        RoomNoGUI();
                    }
                });
            }
        });

    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    private void RoomLockGUI(){
        JFrame frame3 = new JFrame("Lock Room");
        frame3.setSize(350,140);
        JPanel upperPanel = new JPanel();
        JPanel lowerPanel = new JPanel();
        JPanel centerPanel = new JPanel();
        frame3.getContentPane().add(upperPanel, "North");
        frame3.getContentPane().add(centerPanel, "Center");
        frame3.getContentPane().add(lowerPanel, "South");
        upperPanel.setSize(500,100);
        upperPanel.setLayout(new FlowLayout());
        centerPanel.setSize(500,100);
        centerPanel.setLayout(new FlowLayout());
        lowerPanel.setSize(500,100);
        lowerPanel.setLayout(new BorderLayout());
        RLText = new JTextArea("");
        RLText =new JTextArea(1, 5);
        RLText.setEditable(true);
        RLText.setLineWrap(true);
        RLText.setWrapStyleWord(true);
        label = new JLabel("Room No.*");
        Lock = new JButton("Lock");
        unLock = new JButton("Unlock");
        CleanerLock=new JButton("Cleaner Lock");
        ErrorText = new JTextArea("");
        ErrorText=new JTextArea(1, 5);
        ErrorText.setEditable(true);
        ErrorText.setLineWrap(true);
        ErrorText.setWrapStyleWord(true);
        upperPanel.setBackground(Color.decode("#90989E"));
        centerPanel.setBackground(Color.decode("#90989E"));
        lowerPanel.setBackground(Color.decode("#90989E"));
        upperPanel.add(label);
        upperPanel.add(RLText);
        centerPanel.add(Lock);
        centerPanel.add(CleanerLock);
        centerPanel.add(unLock);
        lowerPanel.add(ErrorText,BorderLayout.SOUTH);
        frame3.setVisible(true);
        Lock.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String Result = RLText.getText().toString();

                if(number.equals(Result)){
                    CST[roomID].SendData("Lock..");
                    RLText.setText("");
                    ErrorText.setText("Room Locked");
                    Txt5.append("Room Number "+number +" Locked\n\n");
                    frame3.setVisible(false);
                    frame3.dispose();
                }else{
                    ErrorText.setText("Invaild Room Number");
                    RLText.setText("");
                }
            }
        });
        CleanerLock.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String Result = RLText.getText().toString();

                if(number.equals(Result)){
                    CST[roomID].SendData("LockClean..");
                    RLText.setText("");
                    ErrorText.setText("Room Locked From Cleaner");
                    Txt5.append("Room Number "+number +" Locked From Cleaner\n\n");
                    frame3.setVisible(false);
                    frame3.dispose();
                }else{
                    ErrorText.setText("Invaild Room Number");
                    RLText.setText("");
                }
            }
        });
        unLock.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String Result = RLText.getText().toString();

                if(number.equals(Result)){
                    CST[roomID].SendData("UnLocked..");
                    RLText.setText("");
                    ErrorText.setText("Room Unlocked");
                    Txt5.append("Room Number "+number +" Unlocked\n\n");
                    frame3.setVisible(false);
                    frame3.dispose();
                }else{
                    ErrorText.setText("Invaild Room Number");
                    RLText.setText("");
                }
            }
        });

    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    private void DatabaseGUI(){
        JFrame frame2 = new JFrame("Database Search");

        frame2.setSize(1390,768);

        JPanel upperPanel = new JPanel();
        JPanel lowerPanel = new JPanel();
        frame2.getContentPane().add(upperPanel, "North");
        frame2.getContentPane().add(lowerPanel, "South");
        upperPanel.setSize(500,100);
        upperPanel.setLayout(new FlowLayout());
        DSText = new JTextArea("");
        DSText=new JTextArea(1, 5);
        DSText.setEditable(true);
        DSText.setLineWrap(true);
        DSText.setWrapStyleWord(true);

        DataSearch = new JButton("Search Database");
        upperPanel.add(DataSearch);
        upperPanel.add(DSText);
        upperPanel.setBackground(Color.red);
        lowerPanel.setBackground(Color.decode("#90989E"));
        Txt3 = new JTextArea(30, 30);
        Txt3.setEditable(false);
        Txt3.setLineWrap(true);
        Txt3.setWrapStyleWord(true);
        Txt3.append("Contents of Database:\n");
        Txt3.append("Status:\t\tDate:              Time:\n\n");
        lowerPanel.add(new JScrollPane(Txt3));

        Txt4 = new JTextArea(30, 30);
        Txt4.setEditable(false);
        Txt4.setLineWrap(true);
        Txt4.setWrapStyleWord(true);
        Txt4.append("Search Results:\nStatus:\t\tDate:              Time:\n\n");
        lowerPanel.add(new JScrollPane(Txt4));
        frame2.pack();
        frame2.setVisible(true);
        DatabaseSearch();
        DataSearch.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String search = DSText.getText();
                Txt4.setText("");
                Txt4.append("Search Results:\nStatus:\t\tDate:              Time:\n\n");
                String[] lines = Txt3.getText().split("\\n");
                for(int i = 0 ; i< lines.length; i++) {
                    if(lines[i].contains(search)) {
                        Txt4.append(lines[i] + "\n");
                    }
                }

            }
        });

    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void DatabaseSearch() {
        (new dataSearch()).execute();
    }
    class dataSearch extends SwingWorker<Void, String> {
        @Override
        protected Void doInBackground() throws Exception {
            try {
                System.out.print("Database");
                String myDriver = "com.mysql.jdbc.Driver";
                Class.forName(myDriver);
                conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "");


                Statement statement = conn.createStatement();

                // query database
                ResultSet resultSet = statement.executeQuery( "SELECT * FROM hotel" );

                // process query results
                StringBuffer results = new StringBuffer();
                ResultSetMetaData metaData = resultSet.getMetaData();
                int numberOfColumns = metaData.getColumnCount();

                for ( int i = 4; i <= numberOfColumns; i++ ) {
                    results.append( metaData.getColumnName( i )
                            + "\t\t" );
                }
                results.append( "" );
                while ( resultSet.next() ) {
                    for ( int i = 2; i <= numberOfColumns; i++ ) {
                        results.append( resultSet.getObject( i )
                                + "\t\t" );
                    }
                    results.append( "\n" );
                }
                Txt3.append(results+"");
                statement.close();

            }catch(Exception io){}
            return null;
        }
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    private void RoomNoGUI(){
        JFrame frame3 = new JFrame("Room No. Change");
        frame3.setSize(350,160);
        JPanel upperPanel = new JPanel();
        JPanel lowerPanel = new JPanel();
        JPanel centerPanel = new JPanel();
        frame3.getContentPane().add(upperPanel, "North");
        frame3.getContentPane().add(centerPanel, "Center");
        frame3.getContentPane().add(lowerPanel, "South");
        upperPanel.setSize(500,100);
        upperPanel.setLayout(new GridLayout(2,2));
        centerPanel.setSize(500,100);
        centerPanel.setLayout(new FlowLayout());
        lowerPanel.setSize(500,100);
        lowerPanel.setLayout(new BorderLayout());
        RoomNoText = new JTextArea("");
        RoomNoText =new JTextArea(1, 5);
        RoomNoText.setEditable(true);
        RoomNoText.setLineWrap(true);
        RoomNoText.setWrapStyleWord(true);
        upperPanel.setBackground(Color.decode("#90989E"));
        centerPanel.setBackground(Color.decode("#90989E"));
        lowerPanel.setBackground(Color.decode("#90989E"));
        CText = new JTextArea("");
        CText =new JTextArea(1, 5);
        CText.setEditable(true);
        CText.setLineWrap(true);
        CText.setWrapStyleWord(true);

        labelR = new JLabel("Room No.*");
        labelC = new JLabel("Change To");

        UpdateChange = new JButton("Update Change");


        ErrorText = new JTextArea("");
        ErrorText=new JTextArea(1, 5);
        ErrorText.setEditable(true);
        ErrorText.setLineWrap(true);
        ErrorText.setWrapStyleWord(true);

        upperPanel.add(labelR);
        upperPanel.add(RoomNoText);
        upperPanel.add(labelC);
        upperPanel.add(CText);
        centerPanel.add(UpdateChange);

        lowerPanel.add(ErrorText,BorderLayout.SOUTH);
        frame3.setVisible(true);
        UpdateChange.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String RoomNo = RoomNoText.getText().toString();
                String RoomNoChange = CText.getText().toString();
                int num= Integer.parseInt(RoomNoChange);
                if(RoomNo.equals(RoomNoChange)){
                    ErrorText.setText("Both Number are the Same");
                }
                else {
                    if (number.equals(RoomNo)) {
                        if (num > 0) {
                            CST[roomID].SendData(RoomNoChange + "");
                            ErrorText.setText("Room Updated");
                            RoomNoText.setText("");
                            Txt5.append("Room Number Changed From "+number +" to "+RoomNoChange+"\n\n");
                            clientCount = 0;
                            frame3.setVisible(false);
                            frame3.dispose();
                        } else {
                            ErrorText.setText("Enter Correct Room Number");
                            RoomNoText.setText("");
                        }
                    } else {
                        ErrorText.setText("Invaild Room Number");
                        RoomNoText.setText("");
                    }
                }
            }
        });
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////
    public void Socket() {
        (new Sock()).execute();
    }
    class Sock extends SwingWorker<Void, String> {
        @Override
        protected Void doInBackground() throws Exception {
            ServerSocket m_ServerSocket = new ServerSocket(12345);

            CST = new ClientServiceThread[50];
            for(id=0;id<50;id++) {
                clientCount=0;
                Socket clientSocket = m_ServerSocket.accept();
                CST[id] = new ClientServiceThread(clientSocket, id);
                CST[id].start();
            }
            return null;
        }
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////
    class ClientServiceThread extends Thread {
        Socket clientSocket;
        int clientID = -1;
        boolean running = true;
        int count=0;

        ClientServiceThread(Socket s, int i) {
            clientSocket = s;
            clientID = i;
        }

        public void run() {

            //Txt2.append("Accepted Client : ID - " + clientID + "\nAddress - " + clientSocket.getInetAddress().getHostName());
            System.out.println("Accepted Client : ID - " + clientID + " : Address - " + clientSocket.getInetAddress().getHostName());
            try {
                BufferedReader   in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                while (running) {

                    String date_time = new SimpleDateFormat("yyyy/MM/dd   HH:mm:ss").format(Calendar.getInstance().getTime());
                    count++;
                    String clientCommand = in.readLine();
                    System.out.println("Client Says :" + clientCommand);

                    int len =clientCommand.length();
                    System.out.println("\r\nlen"+len);
                    // Txt1.append("Client Says:"+clientCommand+"\t"+new SimpleDateFormat("yyyy/MM/dd   HH:mm:ss").format(Calendar.getInstance().getTime())+"\n");
                    if (clientCommand.equalsIgnoreCase("quit")) {
                        running = false;
                        System.out.print("Stopping client thread for client : " + clientID);
                    }else if(clientCommand.equals("431") && clientCount==0 || clientCommand.equals("436") && clientCount==0
                            || clientCommand.equals("593") && clientCount==0){

                        roomID=clientID;
                        Txt2.append("Room " + clientCommand + " is Connected       Room ID: " + clientID + "\n\n");
                        System.out.print("Connected" + clientCommand);
                        number = clientCommand;
                        clientCount++;

                    }else if(clientCommand.equals("431")){
                        Txt1.append(clientCommand +" Scanned"+"\t\t" +date_time+"\n");
                        Database("431",date_time);
                    }else if(clientCommand.equals("436")){
                        Txt1.append(clientCommand +" Scanned"+"\t\t" +date_time+"\n");
                        Database("436",date_time);
                    }else if(clientCommand.equals("593")){
                        Txt1.append(clientCommand +" Scanned"+"\t\t" +date_time+"\n");
                        Database("593",date_time);
                     }else if(clientCommand.equals("Cleaning")){
                        Txt1.append("Master Scanned"+"\t" +date_time+"\n");
                        Database("Master",date_time);
                    }
                    else ;

                    ///////////////////////////////////////////////////////////////////////////////
                    if(clientCommand.contains("App")){
                        Txt2.append(clientCommand +"\n\n");
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        private void SendData(String s){
            try {
                PrintWriter out = new PrintWriter(new OutputStreamWriter(clientSocket.getOutputStream()));
                System.out.print("Send data");
                out.println(s);
                out.flush();
            }catch(IOException io){

            }
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Database(String card,String DT){
            try {

                String myDriver = "com.mysql.jdbc.Driver";
                Class.forName(myDriver);
                conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "");

                String query = " insert into hotel (card_scanned, date_time)"
                        + " values (?, ?)";

                PreparedStatement preparedStmt = conn.prepareStatement(query);
                preparedStmt.setString (1,card );
                preparedStmt.setString (2, DT);
                preparedStmt.execute();
                conn.close();
                System.out.print("Connection Closed\r\n");
            }catch(Exception io){

            }
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////
}