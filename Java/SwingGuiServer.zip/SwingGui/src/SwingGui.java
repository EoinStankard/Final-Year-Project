
import java.io.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.ServerSocket;
import java.net.Socket;
import javax.swing.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.*;


public class SwingGui{
    JTextArea Txt1,Txt2,Txt3,Txt4, RLText,DSText,ErrorText;
    JButton DoorLock,Database,Clear,unLock,Lock,DataSearch;
    Date newDate = new Date();
    ClientServiceThread[] CST;

    public static void main(String[] args) {
        try{
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
        }
        catch(Exception ex ){
            ex.printStackTrace();

        }
        new SwingGui();
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    public SwingGui() {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {

                GUI();
            }
        });
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    private void GUI() {

        JFrame frame = new JFrame("Hotel Server");
        frame.setSize(1366,768);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel upperPanel = new JPanel();
        JPanel lowerPanel = new JPanel();
        frame.getContentPane().add(upperPanel, "North");
        frame.getContentPane().add(lowerPanel, "South");
        upperPanel.setSize(500,100);
        upperPanel.setLayout(new FlowLayout());

        Clear = new JButton("Clear");
        Database = new JButton("Database");
        DoorLock = new JButton("Lock Room");
        //JButton Search = new JButton("Search");

        upperPanel.add(Clear);
        upperPanel.add(Database);
        upperPanel.add(DoorLock);

        //upperPanel.add(Search);
        Txt1 = new JTextArea(30, 28);
        Txt1.setEditable(false);
        Txt1.setLineWrap(true);
        Txt1.setWrapStyleWord(true);
        Txt1.append("Status:\t\tDate:              Time:\n\n");
        lowerPanel.add(new JScrollPane(Txt1));
        Txt2 = new JTextArea(30, 28);
        Txt2.setEditable(false);
        Txt2.setLineWrap(true);
        Txt2.setWrapStyleWord(true);
        Txt2.append("Connections:\n\n");
        lowerPanel.add(new JScrollPane(Txt2));
        frame.pack();
        frame.setVisible(true);
        Socket();
        Clear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                Txt1.setText("");
                Txt1.append("Status:\t\tDate:              Time:\n\n");
            }
        });

        DoorLock.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                javax.swing.SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        RoomLockGUI();
                    }
                });
            }
        });

        Database.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                javax.swing.SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        Database.setEnabled(false);
                        DatabaseGUI();
                    }
                });
            }
        });

    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    private void RoomLockGUI(){
        JFrame frame3 = new JFrame("Lock Room");
        frame3.setSize(350,140);
        JPanel upperPanel = new JPanel();
        JPanel lowerPanel = new JPanel();
        frame3.getContentPane().add(upperPanel, "North");
        frame3.getContentPane().add(lowerPanel, "South");
        upperPanel.setSize(500,100);
        upperPanel.setLayout(new FlowLayout());
        lowerPanel.setSize(500,100);
        lowerPanel.setLayout(new BorderLayout());
        RLText = new JTextArea("");
        RLText =new JTextArea(1, 5);
        RLText.setEditable(true);
        RLText.setLineWrap(true);
        RLText.setWrapStyleWord(true);
        JLabel label = new JLabel("Room No.");
        Lock = new JButton("Lock");
        unLock = new JButton("Unlock");
        ErrorText = new JTextArea("");
        ErrorText=new JTextArea(1, 5);
        ErrorText.setEditable(true);
        ErrorText.setLineWrap(true);
        ErrorText.setWrapStyleWord(true);

        upperPanel.add(label);
        upperPanel.add(RLText);
        lowerPanel.add(Lock,BorderLayout.LINE_START);
        lowerPanel.add(unLock,BorderLayout.LINE_END);
        lowerPanel.add(ErrorText,BorderLayout.SOUTH);
        frame3.setVisible(true);
        Lock.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String Result = RLText.getText().toString();
                String Room1 = "431";
                String Room2 = "431";
                if(Room1.equals(Result)){
                    CST[0].SendData("Lock");
                    RLText.setText("");
                    ErrorText.setText("Room Locked");
                }else if(Room2.equals(Result)){
                    CST[1].SendData("Lock");
                    RLText.setText("");
                    ErrorText.setText("Room Locked");
                }else{
                    ErrorText.setText("Invaild Room Number");
                    RLText.setText("");
                }
            }
        });
        unLock.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String Result = RLText.getText().toString();
                String Room1 = "431";
                String Room2 = "431";
                if(Room1.equals(Result)){
                    CST[0].SendData("UnLocked");
                    RLText.setText("");
                    ErrorText.setText("Room Unlocked");
                }else if(Room2.equals(Result)){
                    CST[1].SendData("UnLocked");
                    RLText.setText("");
                    ErrorText.setText("Room Unlocked");
                }else{
                    ErrorText.setText("Invaild Room Number");
                    RLText.setText("");
                }
            }
        });

    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////
    private void DatabaseGUI(){
        JFrame frame2 = new JFrame("Database Search");

        frame2.setSize(1366,768);

        JPanel upperPanel = new JPanel();
        JPanel lowerPanel = new JPanel();
        frame2.getContentPane().add(upperPanel, "North");
        frame2.getContentPane().add(lowerPanel, "South");
        upperPanel.setSize(500,100);
        upperPanel.setLayout(new FlowLayout());
        DSText = new JTextArea("");
        DSText=new JTextArea(1, 5);
        DSText.setEditable(true);
        DSText.setLineWrap(true);
        DSText.setWrapStyleWord(true);

        DataSearch = new JButton("Search Database");
        upperPanel.add(DataSearch);
        upperPanel.add(DSText);
        Txt3 = new JTextArea(30, 28);
        Txt3.setEditable(false);
        Txt3.setLineWrap(true);
        Txt3.setWrapStyleWord(true);
        Txt3.append("Contents of Database:\n\n");
        lowerPanel.add(new JScrollPane(Txt3));

        Txt4 = new JTextArea(30, 28);
        Txt4.setEditable(false);
        Txt4.setLineWrap(true);
        Txt4.setWrapStyleWord(true);
        Txt4.append("Search Results:\n\n");
        lowerPanel.add(new JScrollPane(Txt4));
        frame2.pack();
        frame2.setVisible(true);

        DataSearch.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });

    }
    /////////////////////////////////////////////////////////////////////////////////////////////////
    public void Socket() {
        (new Sock()).execute();
    }
    class Sock extends SwingWorker<Void, String> {
        @Override
        protected Void doInBackground() throws Exception {
            ServerSocket m_ServerSocket = new ServerSocket(12345);
            int id;
            CST = new ClientServiceThread[50];
            for(id=0;id<50;id++) {
                Socket clientSocket = m_ServerSocket.accept();
                CST[id] = new ClientServiceThread(clientSocket, id);
                CST[id].start();
            }
            return null;
        }
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////
    class ClientServiceThread extends Thread {
        Socket clientSocket;
        int clientID = -1;
        boolean running = true;
        int count=0;

        ClientServiceThread(Socket s, int i) {
            clientSocket = s;
            clientID = i;
        }

        public void run() {

            //Txt2.append("Accepted Client : ID - " + clientID + "\nAddress - " + clientSocket.getInetAddress().getHostName());
            System.out.println("Accepted Client : ID - " + clientID + " : Address - " + clientSocket.getInetAddress().getHostName());
            try {
                BufferedReader   in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                //PrintWriter   out = new PrintWriter(new OutputStreamWriter(clientSocket.getOutputStream()));

                while (running) {
                    count++;
                    String clientCommand = in.readLine();
                    System.out.println("Client Says :" + clientCommand);

                   // Txt1.append("Client Says:"+clientCommand+"\t"+new SimpleDateFormat("yyyy/MM/dd   HH:mm:ss").format(Calendar.getInstance().getTime())+"\n");
                    if (clientCommand.equalsIgnoreCase("quit")) {
                        running = false;
                        System.out.print("Stopping client thread for client : " + clientID);
                    }else if(clientCommand.equals("Room 431")){
                        Txt2.append(clientCommand +" is Connected\n\n");
                        System.out.print("Connected"+ clientCommand);
                    }else if(clientCommand.equals("431")){
                        Txt1.append(clientCommand +" Scanned"+"\t\t"
                                +new SimpleDateFormat("yyyy/MM/dd   HH:mm:ss").format(Calendar.getInstance().getTime())+"\n");

                    }else if(clientCommand.equals("Cleaning")){
                        Txt1.append("Master Scanned"+"\t"
                                +new SimpleDateFormat("yyyy/MM/dd   HH:mm:ss").format(Calendar.getInstance().getTime())+"\n");
                    }
                    else ;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        private void SendData(String s){
            try {
                PrintWriter out = new PrintWriter(new OutputStreamWriter(clientSocket.getOutputStream()));
                System.out.print("Send data");
                out.println(s);
                out.flush();
            }catch(IOException io){

            }
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////
}