#include "mbed.h"
#include <TCPSocket.h>
#include <EthInterface.h>
#include "EthernetInterface.h"

#include "PN532_SPI.h"
#include "snep.h"
#include "NdefMessage.h"
#include "NfcAdapter.h"
#include "PN532.h"
#include "NdefRecord.h"
#include "string.h"


char RoomServer[] = "Room 431\n";
char StayConnected[] = ".";
const char* stri=NULL;
const char* found=NULL;
char newline[] = "\r\n";
char Room[]="431\n";
char Cleaning[]="Cleaning";
char Error[]="Error\n";
const int entry=1;
uint8_t ndefBuf[128];
DigitalOut red(LED_RED);
DigitalOut green(LED_GREEN);
DigitalOut blue(LED_BLUE);


int main() {
    SPI spi(D11, D12, D13);
    PN532_SPI pn532spi(spi, D10);
    NfcAdapter nfc = NfcAdapter(pn532spi);
    nfc.begin();
    EthernetInterface eth;
    eth.connect();
    printf("Connecting\r\n");
    printf("IP Address is %s\r\n", eth.get_ip_address());

    TCPSocket sock;
    sock.open(&eth);
    int temp = sock.connect("192.168.137.1" , 12345);
    printf("Socket connection value %d \r\n",temp );    
    
    printf("Done\r\n"); 
    
    red=1;
    green=1;
    blue=1;
    char buffer[300];
    int ret;
    int ServerCount=0;
    while(true) {
        
        printf("\r\n1");
       blue=0;
       wait(1);
       //sock.send(StayConnected , sizeof(StayConnected)-1);
       if(nfc.tagPresent())
        {
            printf("\r\n2");
            blue=1;
            printf("\r\nTag present");
            NfcTag tag = nfc.read();
            if(tag.hasNdefMessage()){
                NdefMessage message = tag.getNdefMessage();
                int recordCount = message.getRecordCount();
                for(int i = 0;i<recordCount;i++){
                    NdefRecord record = message.getRecord(i);
        
                    int payloadLength = record.getPayloadLength();
                    uint8_t payload[payloadLength];
                    record.getPayload(payload);
                    string payLoadAsString="";
                    
                        
                    for(int c=0; c<payloadLength; c++){
                        payLoadAsString += (char)payload[c];        
                    }
                    const char* str = payLoadAsString.c_str();
                    printf("NFC Tag: ");
                    printf(str);
                    stri ="";
                    stri=str;    
                }
                if(found=strstr(stri,Room)){
                    printf("\r\nFound :");
                    printf(found);
                    sock.send(Room , sizeof(Room)-1);
                    found=NULL;
                    stri=NULL;
                    green=0;
                    wait(2);
                    green=1;
                }else if(found=strstr(stri,Cleaning)){
                    printf("\r\nFound :");
                    printf(found);
                    sock.send(Cleaning , sizeof(Cleaning)-1);
                    found=NULL;
                    stri=NULL;
                    green=0;
                    wait(2);
                    green=1;
                }else{
                    printf("\r\nError"); 
                    sock.send(Error , sizeof(Error)-1);
                    red =0;
                    wait(2);
                    red=1;
                }   
            }         
        } 
        else if(ServerCount == 0){
            sock.send(RoomServer , sizeof(RoomServer)-1);
            wait(2);
            ServerCount++;
        } 
        else{
            //sock.send(hello , sizeof(hello)-1);
        }  
        printf("\r\n3");
        printf("Socket connection value %d \r\n",temp );   
    }
    printf("\r\n4");
    sock.close();
    eth.disconnect();
    while(1){
        printf("\r\n5");
    }
}
