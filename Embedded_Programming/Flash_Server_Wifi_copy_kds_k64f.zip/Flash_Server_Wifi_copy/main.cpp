#include "mbed.h"
#include <TCPSocket.h>
#include <EthInterface.h>
#include "EthernetInterface.h"

#include "PN532_SPI.h"
#include "snep.h"
#include "NdefMessage.h"
#include "NfcAdapter.h"
#include "PN532.h"
#include "NdefRecord.h"
#include "string.h"
#include "FreescaleIAP.h"
#include "ESP8266Interface.h"
 
#define true 1
#define false 0

ESP8266Interface wifi(D1, D0);

const char* nfcTag=NULL;
const char* found=NULL;
char newline[] = "\n";
char Room[]="431\n";
char TAG[]="";
//char *Room;
char Cleaning[]="Cleaning\n";
char Error[]="Error\n";
int entry=0;
uint8_t ndefBuf[128];
DigitalOut red(LED_RED);
DigitalOut green(LED_GREEN);
DigitalOut blue(LED_BLUE);

char buffer[300];
int received;
int ServerCount=0;
char *ret;
void ClearBuffer();

char lock[] = "Lock..\n";
char unlock[] = "UnLocked..";
int address = flash_size() - SECTOR_SIZE;           //Write in last sector
char *fRoom = (char*)address;
int *ffRoom = (int*)address;

int main() {
    SPI spi(D11, D12, D13);
    PN532_SPI pn532spi(spi, D10);
    NfcAdapter nfc = NfcAdapter(pn532spi);
    nfc.begin();
    
    
    //EthernetInterface eth;
    //eth.connect();
    //printf("Connecting\r\n");
    //printf("IP Address is %s\r\n", eth.get_ip_address());
    //TCPSocket sock;
    //sock.open(&eth);
    //sock.set_blocking(false);
    //int temp = sock.connect("192.168.137.1" , 12345);
    
    TCPSocket sock;
    wifi.connect("SKY6A8D3","DPARETCS", NSAPI_SECURITY_WPA_WPA2);
    //wifi.connect("Eoins iPhone","stankard", NSAPI_SECURITY_WPA_WPA2);
    sock.open(&wifi);
    //sock.connect("172.20.10.4", 12345);
    sock.connect("192.168.0.9", 12345);
    printf("Connecting\r\n");
    printf("IP Address is %s\r\n", wifi.get_ip_address());
    sock.set_blocking(false);
    //int temp = sock.connect("192.168.137.1" , 12345);
    
    //printf("Socket connection value %d + address %d\r\n",temp,address );    
    
    printf("Done\r\n"); 
    
    red=1;
    green=1;
    blue=1;
    
    
    if (ffRoom[0] == -1) {
        erase_sector(address);
        program_flash(address,Room, 8); 
        printf("Room Stored in flash = %s\r\n",fRoom);
    }
    else{
        printf("Read From flash = %s\r\n",fRoom);
        strcpy(Room,fRoom);
    }
    
    
        
    while(true) {
       
       bool door = true; 
       blue=0;
       wait(1);
       if(nfc.tagPresent())
        {   
            printf("Received %s\r\n",Room);
            printf("\r\n2");
            blue=1;
            printf("\r\nTag present %s",Room);
            NfcTag tag = nfc.read();
            if(tag.hasNdefMessage()){
                NdefMessage message = tag.getNdefMessage();
                int recordCount = message.getRecordCount();
                for(int i = 0;i<recordCount;i++){
                    NdefRecord record = message.getRecord(i);
        
                    int payloadLength = record.getPayloadLength();
                    uint8_t payload[payloadLength];
                    record.getPayload(payload);
                    string payLoadAsString="";
                    
                        
                    for(int c=0; c<payloadLength; c++){
                        payLoadAsString += (char)payload[c];        
                    }
                    const char* str = payLoadAsString.c_str();
                    printf("NFC Tag: ");
                    printf(str);
                    nfcTag ="";
                    nfcTag=str;   
                }
                
                
                
              if(found=strstr(nfcTag,Cleaning)){
                    if(entry==1){
                        sock.send(Cleaning , sizeof(Cleaning)-1);
                        found=NULL;
                        nfcTag=NULL;
                        green=0;
                        wait(2);
                        green=1;
                    }else{
                        red=0;
                        wait(2);
                        red=1;
                    }
                }else{
                    blue=0;
                    sock.send(nfcTag ,strlen(nfcTag));
                    blue=0;
                    sock.send(Room ,sizeof(Room));
                    blue=0;
                    ClearBuffer();
                    wait(1);
                    received=0;
                    sock.recv(buffer, sizeof(buffer)-1);

                    if(strcmp(buffer, "TRUE\n")==3){
                        blue=1;
                        sock.send(Room , sizeof(Room)-1);
                        found=NULL;
                        nfcTag=NULL;
                        green=0;
                        wait(2);
                        green=1;
                        ClearBuffer();
                    }else{
                        blue=1;
                        sock.send(Error , sizeof(Error)-1);
                        nfcTag=NULL;
                        red =0;
                        wait(2);
                        red=1;
                    }
                }   
            }         
        } 
        else if(ServerCount == 0){
            sock.send(Room, sizeof(Room)-1);
            wait(2);
            ServerCount++;
        } 
        
        
        while(door==true){
            ClearBuffer();
            received = sock.recv(buffer, sizeof(buffer)-1);
            int len2 = strlen(Room);
            int lenF = strcmp(buffer, "UnLocked..\n");
            int lenFF = strcmp(buffer, "LockClean..\n");
            int lenFFF = strcmp(buffer, "Lock..\n");
            
            printf("strlen(Room) :  %d + %d+ %d + %d +%s\r\n", len2,lenF,lenFF,lenFFF,buffer );
            int lenB = strlen(buffer);
            if (received < 0){
              door=false; 
            }else if(strcmp(buffer, "UnLocked..\n")==3/*received == 12*/){//unlock
                entry =1;
                ClearBuffer();
                received=0;
            }else if(strcmp(buffer, "Lock..\n")==3/*received == 8*/){//Lock sent from server
              printf("Locked\r\n");
              ClearBuffer();
              received=0;
              while(strcmp(buffer, "UnLocked..\n")!=3/*received!= 12*/){//wait for unlock
                received = sock.recv(buffer, sizeof(buffer)-1);
                blue=1;
                red=0;  
              }
              red=1;
              ClearBuffer();
              received=0;
              door=false; 
              
            }else if(strcmp(buffer, "LockClean..\n")==3/*received == 13*/ ){//Cleaner Lock
                entry = 0;
                ClearBuffer();
                received=0;
            }else if(strcmp(buffer, "436\n")==3 || strcmp(buffer, "431\n")==3 || strcmp(buffer, "593\n")==3/*received <=7*/){//Number change
                ServerCount=0; 
                int len1 = strlen(buffer);
                printf("strlen(str1) :  %d\r\n", len1 );
                memset(Room, '\0', sizeof(Room)-1);
                int lenb = strlen(buffer);
                buffer[lenb-2]='\0';
                strcpy(Room,buffer);
                strcat(Room,"\n");
                ret=Room;
                int len = strlen(Room);
                erase_sector(address);
                program_flash(address,Room, 8); 
                ClearBuffer();
                received=0;
                  
            }else if(strcmp(buffer, "apptrue\n")==3){
                blue=1;
                found=NULL;
                nfcTag=NULL;
                green=0;
                wait(2);
                green=1;
                ClearBuffer();
            }else{
                ClearBuffer();
                door=false;
            }
        }  
    }
    sock.close();
    //eth.disconnect();
    wifi.disconnect();
    while(1){
        printf("\r\n5");
    }
}


void ClearBuffer(){
    int i=0;
    for(i=0;i<=received;i++){
        buffer[i] = '\0';
    }
}
