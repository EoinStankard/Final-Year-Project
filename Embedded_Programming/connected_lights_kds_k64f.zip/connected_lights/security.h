

/*

 * Copyright (c) 2015 ARM Limited. All rights reserved.

 * SPDX-License-Identifier: Apache-2.0

 * Licensed under the Apache License, Version 2.0 (the License); you may

 * not use this file except in compliance with the License.

 * You may obtain a copy of the License at

 *

 * http://www.apache.org/licenses/LICENSE-2.0

 *

 * Unless required by applicable law or agreed to in writing, software

 * distributed under the License is distributed on an AS IS BASIS, WITHOUT

 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

 * See the License for the specific language governing permissions and

 * limitations under the License.

 */

#ifndef __SECURITY_H__

#define __SECURITY_H__

 

#include <inttypes.h>

 

#define MBED_DOMAIN "788c6a90-5d8f-416c-8da3-4bf0173ba101"

#define MBED_ENDPOINT_NAME "49edaa68-1969-4183-a07e-22b0998f2bf8"

 

const uint8_t SERVER_CERT[] = "-----BEGIN CERTIFICATE-----\r\n"

"MIIBmDCCAT6gAwIBAgIEVUCA0jAKBggqhkjOPQQDAjBLMQswCQYDVQQGEwJGSTEN\r\n"

"MAsGA1UEBwwET3VsdTEMMAoGA1UECgwDQVJNMQwwCgYDVQQLDANJb1QxETAPBgNV\r\n"

"BAMMCEFSTSBtYmVkMB4XDTE1MDQyOTA2NTc0OFoXDTE4MDQyOTA2NTc0OFowSzEL\r\n"

"MAkGA1UEBhMCRkkxDTALBgNVBAcMBE91bHUxDDAKBgNVBAoMA0FSTTEMMAoGA1UE\r\n"

"CwwDSW9UMREwDwYDVQQDDAhBUk0gbWJlZDBZMBMGByqGSM49AgEGCCqGSM49AwEH\r\n"

"A0IABLuAyLSk0mA3awgFR5mw2RHth47tRUO44q/RdzFZnLsAsd18Esxd5LCpcT9w\r\n"

"0tvNfBv4xJxGw0wcYrPDDb8/rjujEDAOMAwGA1UdEwQFMAMBAf8wCgYIKoZIzj0E\r\n"

"AwIDSAAwRQIhAPAonEAkwixlJiyYRQQWpXtkMZax+VlEiS201BG0PpAzAiBh2RsD\r\n"

"NxLKWwf4O7D6JasGBYf9+ZLwl0iaRjTjytO+Kw==\r\n"

"-----END CERTIFICATE-----\r\n";

 

const uint8_t CERT[] = "-----BEGIN CERTIFICATE-----\r\n"

"MIIB0DCCAXOgAwIBAgIENiMKMDAMBggqhkjOPQQDAgUAMDkxCzAJBgNVBAYTAkZ\r\n"

"JMQwwCgYDVQQKDANBUk0xHDAaBgNVBAMME21iZWQtY29ubmVjdG9yLTIwMTYwHh\r\n"

"cNMTYxMDE4MTEwOTU5WhcNMTYxMjMxMDYwMDAwWjCBoTFSMFAGA1UEAxNJNzg4Y\r\n"

"zZhOTAtNWQ4Zi00MTZjLThkYTMtNGJmMDE3M2JhMTAxLzQ5ZWRhYTY4LTE5Njkt\r\n"

"NDE4My1hMDdlLTIyYjA5OThmMmJmODEMMAoGA1UECxMDQVJNMRIwEAYDVQQKEwl\r\n"

"tYmVkIHVzZXIxDTALBgNVBAcTBE91bHUxDTALBgNVBAgTBE91bHUxCzAJBgNVBA\r\n"

"YTAkZJMFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE9Id2amaudU5krXGnTJFIW\r\n"

"BUhAPQCOYZqEfiFEuWb4Z1p/SQuFDPfIssCir/TAz9CGZm0TjYOS5oOO+MjJ+bt\r\n"

"KzAMBggqhkjOPQQDAgUAA0kAMEYCIQDo/v3iZq0MySfUnho2sxtR6L61h610H2K\r\n"

"zX2odS1quOgIhANQlnpW0cAoVHyK2eKkyecj+nR7ReWA0JHwUf0IebbFS\r\n"

"-----END CERTIFICATE-----\r\n";

 

const uint8_t KEY[] = "-----BEGIN PRIVATE KEY-----\r\n"

"MIGHAgEAMBMGByqGSM49AgEGCCqGSM49AwEHBG0wawIBAQQgWxDJjM+08cTTbxup\r\n"

"GdaVN/nQJgqyzY+KCxg/KyhmjzGhRANCAAT0h3ZqZq51TmStcadMkUhYFSEA9AI5\r\n"

"hmoR+IUS5ZvhnWn9JC4UM98iywKKv9MDP0IZmbRONg5Lmg474yMn5u0r\r\n"

"-----END PRIVATE KEY-----\r\n";

 

#endif //__SECURITY_H__
