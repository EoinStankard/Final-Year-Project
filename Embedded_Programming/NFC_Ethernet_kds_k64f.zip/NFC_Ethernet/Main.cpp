#include "mbed.h"
#include "EthernetInterface.h"
#include "PN532_SPI.h"
#include "snep.h"
#include "NdefMessage.h"
#include "NfcAdapter.h"
#include "PN532.h"
#include "NdefRecord.h"
#include "string.h"
//Serial pc(USBTX, USBRX);
char hello[] = "Hello eoin\r\n";
const char* stri=NULL;
const char* found=NULL;
const char Room[]="431";
const char Cleaning[]="Cleaning";
char Error[]="Error";
const int entry=1;

uint8_t ndefBuf[128];

int main() {
    ////////////////////Ethernet Setup///////////////////////////
    EthernetInterface eth;
    SPI spi(D11, D12, D13);
    PN532_SPI pn532spi(spi, D10);
    NfcAdapter nfc = NfcAdapter(pn532spi);
    //SNEP nfc(pn532spi);
    //nfc.begin();
    eth.init(); //Use DHCP
    eth.connect();
    printf("IP Address is %s", eth.getIPAddress());
    TCPSocketConnection sock;
    sock.connect("192.168.137.1", 12345); 
    printf("  Initializing - ");
    printf("Done\r\n");
    ///////////////////////////////////////////////////////////////
    while(true){
        wait(1);
        printf("Done\r\n");
        wait(1);
        sock.send_all(hello , sizeof(hello)-1);
    }
    while(1) {
        //sock.send_all(hello , sizeof(hello)-1);
        //printf("While....");    
         /*if(nfc.tagPresent())
        {
            printf("Tag present");
            NfcTag tag = nfc.read();
            if(tag.hasNdefMessage()){
                NdefMessage message = tag.getNdefMessage();
                int recordCount = message.getRecordCount();
                for(int i = 0;i<recordCount;i++){
                    NdefRecord record = message.getRecord(i);
        
                    int payloadLength = record.getPayloadLength();
                    uint8_t payload[payloadLength];
                    record.getPayload(payload);
                    string payLoadAsString="";
                    
                        
                    for(int c=0; c<payloadLength; c++){
                        payLoadAsString += (char)payload[c];        
                    }
                    const char* str = payLoadAsString.c_str();
                    printf("NFC Tag: ");
                    printf(str);
                    stri ="";
                    stri=str;    
                }
            }
        } */
    }
    sock.close();
    eth.disconnect();
}

