#include "mbed.h"
#include "PN532_SPI.h"
#include "snep.h"
#include "NdefMessage.h"
#include "NfcAdapter.h"
#include "PN532.h"
#include "NdefRecord.h"
#include "string.h" 


Serial pc(USBTX, USBRX);
DigitalOut red(LED_RED);
DigitalOut green(LED_GREEN);
DigitalOut blue(LED_BLUE);
const char* stri=NULL;
const char* found=NULL;
const char Room[]="431";
const char Cleaning[]="Cleaning";
const char Error[]="Error";
const int entry=1;

int main()
{
    
    pc.printf("Initializing - ");
    SPI spi(D11, D12, D13);
    PN532_SPI pn532spi(spi, D10);
    NfcAdapter nfc = NfcAdapter(pn532spi);
    //SNEP nfc(pn532spi);
    //nfc.begin();
    pc.printf("Done");
    red=1;
    green=1;
    blue=1;
    
    while (1) {
        wait(2);
        blue=0;
        if(nfc.tagPresent())
        {
            blue=1;
            printf("\r\nTag present");
            NfcTag tag = nfc.read();
            if(tag.hasNdefMessage()){
                NdefMessage message = tag.getNdefMessage();
                int recordCount = message.getRecordCount();
                for(int i = 0;i<recordCount;i++){
                    NdefRecord record = message.getRecord(i);
        
                    int payloadLength = record.getPayloadLength();
                    uint8_t payload[payloadLength];
                    record.getPayload(payload);
                    string payLoadAsString="";
                    
                        
                    for(int c=0; c<payloadLength; c++){
                        payLoadAsString += (char)payload[c];        
                    }
                    const char* str = payLoadAsString.c_str();
                    printf("NFC Tag: ");
                    printf(str);
                    stri ="";
                    stri=str;    
                }
                if(found=strstr(stri,Room)){
                    printf("\r\nFound :");
                    printf(found);
                    found=NULL;
                    stri=NULL;
                    green=0;
                    wait(2);
                    green=1;
                }else if(found=strstr(stri,Cleaning)){
                    printf("\r\nFound :");
                    printf(found);
                    found=NULL;
                    stri=NULL;
                    green=0;
                    wait(2);
                    green=1;
                }else{
                    printf("\r\nError");
                    red =0;
                    wait(2);
                    red=1;
                }   
            }         
        }   
    }
}