#include "mbed.h"
#include <TCPSocket.h>
#include <EthInterface.h>
#include "EthernetInterface.h"

#include "PN532_SPI.h"
#include "snep.h"
#include "NdefMessage.h"
#include "NfcAdapter.h"
#include "PN532.h"
#include "NdefRecord.h"
#include "string.h"

#define true 1
#define false 0

const char* stri=NULL;
const char* found=NULL;
char newline[] = "\n";
char Room[]="431\n";
//char *Room;
char Cleaning[]="Cleaning\n";
char Error[]="Error\n";
int entry=1;
uint8_t ndefBuf[128];
DigitalOut red(LED_RED);
DigitalOut green(LED_GREEN);
DigitalOut blue(LED_BLUE);

char buffer[300];
int received;
int ServerCount=0;
char *ret;
void ClearBuffer();


int main() {
    SPI spi(D11, D12, D13);
    PN532_SPI pn532spi(spi, D10);
    NfcAdapter nfc = NfcAdapter(pn532spi);
    nfc.begin();
    EthernetInterface eth;
    eth.connect();
    printf("Connecting\r\n");
    printf("IP Address is %s\r\n", eth.get_ip_address());

    TCPSocket sock;
    sock.open(&eth);
    sock.set_blocking(false);
    int temp = sock.connect("192.168.137.1" , 12345);
    printf("Socket connection value %d \r\n",temp );    
    
    printf("Done\r\n"); 
    
    red=1;
    green=1;
    blue=1;

    
        
    while(true) {
       bool door = true; 
       blue=0;
       wait(1);
       if(nfc.tagPresent())
        {   
            printf("Received %s\r\n",Room);
            printf("\r\n2");
            blue=1;
            printf("\r\nTag present %s",Room);
            NfcTag tag = nfc.read();
            if(tag.hasNdefMessage()){
                NdefMessage message = tag.getNdefMessage();
                int recordCount = message.getRecordCount();
                for(int i = 0;i<recordCount;i++){
                    NdefRecord record = message.getRecord(i);
        
                    int payloadLength = record.getPayloadLength();
                    uint8_t payload[payloadLength];
                    record.getPayload(payload);
                    string payLoadAsString="";
                    
                        
                    for(int c=0; c<payloadLength; c++){
                        payLoadAsString += (char)payload[c];        
                    }
                    const char* str = payLoadAsString.c_str();
                    printf("NFC Tag: ");
                    printf(str);
                    stri ="";
                    stri=str;    
                }
                if(found=strstr(stri,Room) ){
                    printf("\r\nFound1 :");
                    printf(found);
                    sock.send(Room , sizeof(Room)-1);
                    found=NULL;
                    stri=NULL;
                    green=0;
                    wait(2);
                    green=1;
                }else if(found=strstr(stri,Cleaning)){
                    if(entry==1){
                        printf("\r\nFound :");
                        printf(found);
                        sock.send(Cleaning , sizeof(Cleaning)-1);
                        found=NULL;
                        stri=NULL;
                        green=0;
                        wait(2);
                        green=1;
                    }else{
                        red=0;
                        wait(2);
                        red=1;
                    }
                }else{
                    printf("\r\nError"); 
                    sock.send(Error , sizeof(Error)-1);
                    red =0;
                    wait(2);
                    red=1;
                }   
            }         
        } 
        else if(ServerCount == 0){
            sock.send(Room, sizeof(Room)-1);
            wait(2);
            ServerCount++;
        } 
        else{
            
        } 
        
        while(door==true){
            ClearBuffer();
            received = sock.recv(buffer, sizeof(buffer)-1);
            //printf("Received %d chars from 1server:%s\r\n", received, buffer);
            int len2 = strlen(Room);
            printf("strlen(Room) :  %d\r\n", len2 );
            
            if (received <= 0){
              printf("break\r\n");
              door=false; 
            }else if(received==8){//Lock sent from server
              printf("Locked\r\n");
              ClearBuffer();
              received=0;
              while(received!= 12){//wait for unlock
                received = sock.recv(buffer, sizeof(buffer)-1);
                blue=1;
                red=0;  
              }
              red=1;
              ClearBuffer();
              received=0;
              door=false; 
              
            }else if(received == 12){//unlock
                entry =1;
                ClearBuffer();
                received=0;
            }else if(received == 13){//Cleaner Lock
                entry = 0;
                ClearBuffer();
                received=0;
            }else if(received <=7){//Number change
                ServerCount=0; 
                int len1 = strlen(buffer);
                printf("strlen(str1) :  %d\r\n", len1 );
                
                memset(Room, '\0', sizeof(Room)-1);
                int lenb = strlen(buffer);
                buffer[lenb-2]='\0';
                strcpy(Room,buffer);
                strcat(Room,"\n");
                ret=Room;
                printf("EOIN %s\r\n",Room);
                printf("ret %s\r\n",ret);
                int len = strlen(Room);
                printf("strlen(str1) :  %d\r\n", len );
                ClearBuffer();
                received=0;
                  
            }else{
                ClearBuffer();
                door=false;
            }
        }
        //printf("Socket connection value %d \r\n",temp );   
    }
    sock.close();
    eth.disconnect();
    while(1){
        printf("\r\n5");
    }
}


void ClearBuffer(){
    int i=0;
    for(i=0;i<=received;i++){
        printf("%d",i);
        buffer[i] = '\0';
    }
   // memset(buffer, '\0', sizeof(buffer));
}
