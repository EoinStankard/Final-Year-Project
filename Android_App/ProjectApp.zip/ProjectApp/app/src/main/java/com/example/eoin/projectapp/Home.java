package com.example.eoin.projectapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

public class Home extends AppCompatActivity {

    Button login;
    EditText RoomNo;
    Socket client;
    PrintWriter printwriter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        login = (Button)findViewById(R.id.button);
        RoomNo = (EditText)findViewById(R.id.editText);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String num = RoomNo.getText().toString();
                int numm = Integer.parseInt(num);
                if (numm == 431 || numm ==436 || numm ==593) {
                    Intent GuestPage = new Intent(Home.this, guestHome.class);
                    Bundle myData = new Bundle();
                    myData.putInt("RoomNo: ", numm);
                    GuestPage.putExtras(myData);
                    Home.Connect sendMessageTask = new Home.Connect();
                    sendMessageTask.start();
                    startActivity(GuestPage);
                }
                else{
                    Toast.makeText(Home.this,"Please Enter Valid Room Number",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    private class Connect extends Thread {
        public void run() {

            try {
                //client = new Socket("192.168.0.9", 12345); // connect to the server
                client = new Socket("10.12.18.8", 12345); // connect to the server
                client.setKeepAlive(true);
                printwriter = new PrintWriter(new OutputStreamWriter(client.getOutputStream()));
                printwriter.println("App Room: " + RoomNo.getText().toString()); // write the message to output stream

                printwriter.flush();

            } catch (IOException e) {

            }
        }
    }
}
