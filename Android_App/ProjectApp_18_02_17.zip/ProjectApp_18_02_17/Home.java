package com.example.eoin.projectapp;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.*;
import java.net.Socket;

public class Home extends AppCompatActivity {

    Button login;
    EditText RoomNo,Password;
    Socket client;
    PrintWriter printwriter;
    boolean running = true;
    Intent GuestPage;
    Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        context = getApplicationContext();

        login = (Button)findViewById(R.id.button);
        RoomNo = (EditText)findViewById(R.id.editText);
        Password=(EditText)findViewById(R.id.editText2);
        Home.Connect sendMessageTask = new Home.Connect();
        sendMessageTask.setContext(context);
        sendMessageTask.start();

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String num = RoomNo.getText().toString();
                int numm = Integer.parseInt(num);
                String pWord = Password.getText().toString();
                if (numm== 431  || numm == 436 || numm == 593 ) {
                    try {
                        GuestPage = new Intent(Home.this, guestHome.class);
                        Bundle myData = new Bundle();
                        myData.putInt("RoomNo: ", numm);
                        GuestPage.putExtras(myData);
                        printwriter.println(num+" "+pWord);
                        printwriter.flush();

                    } catch(Exception e){
                    }
                }
                else {
                    Toast.makeText(Home.this,"Please Enter Valid Room Number",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    private class Connect extends Thread {
        Context context;
        public void setContext(Context context1){
            context=context1;
        }
        public void run() {

            try {
                client = new Socket("192.168.0.9", 12345); // Home
                //client = new Socket("10.12.18.8", 12345); // EduRoam
                //client = new Socket("172.20.10.4", 12345); // Iphone
                client.setKeepAlive(true);
                printwriter = new PrintWriter(new OutputStreamWriter(client.getOutputStream()));
                printwriter.println("Password "); // write the message to output stream
                printwriter.flush();

                while(running){
                    printwriter.flush();

                    BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
                    String clientCommand = in.readLine();

                    if(clientCommand.equals("TRUE")){
                        printwriter.println("App Room: " + RoomNo.getText().toString());
                        printwriter.flush();
                        startActivityForResult(GuestPage, 2);
                        finish();
                    }else if(clientCommand.equals("connected")){
                        runOnUiThread(new Runnable() {
                            public void run() {
                                Toast.makeText(Home.this,"Connected To Server", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                }
            } catch (IOException e) {

            }
        }
    }
}
