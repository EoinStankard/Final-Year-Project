package com.example.eoin.projectapp;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class guestHome extends AppCompatActivity {
    TextView Roomnum;
    Button clean;
    int RoomNo;
    Socket client;
    PrintWriter printwriter;
    String send;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guest_home);
        clean=(Button)findViewById(R.id.buttonClean);
        Roomnum = (TextView) findViewById(R.id.textView3);


        Intent myLocalIntent = getIntent();
        Bundle myBundle = myLocalIntent.getExtras();
        RoomNo = myBundle.getInt("RoomNo: ");
        Roomnum.setText("" + RoomNo);


        clean.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent cleanPage = new Intent(guestHome.this,Cleaning.class);
                Intent IntentC = getIntent();
                Bundle bundle = IntentC.getExtras();
                bundle.putInt("RoomNum: ",RoomNo);
                cleanPage.putExtras(bundle);
                startActivityForResult(cleanPage,101);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        try	{
            if ((requestCode == 101 ) && (resultCode == Activity.RESULT_OK)){
                Bundle myResultBundle = data.getExtras();
                String time = myResultBundle.getString("time");
                String pillow = myResultBundle.getString("pillow");
                String towel = myResultBundle.getString("towel");
                Toast.makeText(guestHome.this,"You Chose Time: "+time+"\nTowels: "+towel+"\nPillows: "+pillow,
                        Toast.LENGTH_SHORT).show();
                String num = Integer.toString(RoomNo);
                send="\t\tCleaning Service \t       "+num+"                                 "
                        +time+"\t       "+pillow+"\t                         "+towel;
                guestHome.sendData sendMessageTask = new guestHome.sendData();
                sendMessageTask.start();
            }
        }
        catch (Exception e) {

        }
    }//onActivityResult
    private class sendData extends Thread {
        public void run() {
            try {

                    //client = new Socket("192.168.0.9", 12345); // connect to the server
                    client = new Socket("10.12.18.8", 12345); // connect to the server
                    client.setKeepAlive(true);
                    printwriter = new PrintWriter(new OutputStreamWriter(client.getOutputStream()));
                    printwriter.println(send); // write the message to output stream
                    printwriter.flush();
                    Toast.makeText(guestHome.this, "Sent", Toast.LENGTH_SHORT).show();

                } catch(Exception e){

                }

        }
    }
}

