package com.example.eoin.projectapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.*;
import java.net.Socket;

public class Home extends AppCompatActivity {

    Button login,details;
    EditText RoomNo,Password;
    Socket client;
    PrintWriter printwriter;
    boolean running = true;

    String Room431Password;
    String Room436Password;
    String Room593Password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        login = (Button)findViewById(R.id.button);
        details = (Button)findViewById(R.id.button6);
        RoomNo = (EditText)findViewById(R.id.editText);
        Password=(EditText)findViewById(R.id.editText2);
        Home.Connect sendMessageTask = new Home.Connect();
        sendMessageTask.start();

        details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Home.this,"Passwords-\n"+"436: "+Room436Password+"\n431: "+Room431Password+"\n593: "+Room593Password,
                        Toast.LENGTH_SHORT).show();
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String num = RoomNo.getText().toString();
                int numm = Integer.parseInt(num);
                String pWord = Password.getText().toString();


                if (numm== 431 && Room431Password.equals(pWord) || numm == 436 && Room436Password.equals(pWord)|| numm == 593 &&Room593Password.equals(pWord)) {

                    try {
                        Intent GuestPage = new Intent(Home.this, guestHome.class);
                        Bundle myData = new Bundle();
                        myData.putInt("RoomNo: ", numm);
                        GuestPage.putExtras(myData);
                        printwriter.println("App Room: " + RoomNo.getText().toString());
                        printwriter.flush();
                        startActivityForResult(GuestPage, 2);

                    } catch(Exception e){

                    }
                }
                else {
                    Toast.makeText(Home.this,"Please Enter Valid Room Number",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });


    }
    private class Connect extends Thread {
        public void run() {

            try {
               // client = new Socket("192.168.0.9", 12345); // connect to the server
                client = new Socket("10.12.18.8", 12345); // connect to the server
                client.setKeepAlive(true);
                printwriter = new PrintWriter(new OutputStreamWriter(client.getOutputStream()));
                printwriter.println("Password "); // write the message to output stream
                printwriter.flush();

                while(running){


                    //printwriter.println("App Room: " + RoomNo.getText().toString()); // write the message to output stream

                    printwriter.flush();


                        BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
                        String clientCommand = in.readLine();
                        if (clientCommand.contains("R431")) {
                            //Room431Password=null;
                            String entryArray[] = clientCommand.split(",");
                            Room431Password = entryArray[1];
                            printwriter.println("Password " + entryArray[1] + "  " + Room431Password); // write the message to output stream
                            printwriter.flush();

                        } else if (clientCommand.contains("R436")) {
                            //Room436Password=null;
                            String entryArray1[] = clientCommand.split(",");
                            Room436Password = entryArray1[1];
                            printwriter.println("Password " + entryArray1[1] + "  " + Room436Password); // write the message to output stream
                            printwriter.flush();

                        } else if (clientCommand.contains("R593")) {
                            //Room593Password=null;
                            String entryArray2[] = clientCommand.split(",");
                            Room593Password = entryArray2[1];
                            printwriter.println("Password " + entryArray2[1] + "  " + Room593Password); // write the message to output stream
                            printwriter.flush();
                        } else ;
                    }



            } catch (IOException e) {

            }
        }
    }
}
